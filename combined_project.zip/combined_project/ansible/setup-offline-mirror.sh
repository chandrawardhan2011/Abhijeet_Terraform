#!/usr/bin/env bash
# =============================================================================
# setup-offline-mirror.sh
# Run this ONCE on the Terraform/Ansible control node to build a local
# offline package mirror so all Ansible roles can install software without
# internet access on the target VMs.
#
# PHASE A — run on a machine WITH internet (downloads everything)
# PHASE B — run on the Terraform server (serves everything)
#
# Usage:
#   sudo ./setup-offline-mirror.sh download    # PHASE A — grab all packages
#   sudo ./setup-offline-mirror.sh serve       # PHASE B — start the mirrors
#   sudo ./setup-offline-mirror.sh all         # both phases (needs internet)
# =============================================================================
set -e

MIRROR_ROOT="/opt/offline-mirror"
APT_DIR="${MIRROR_ROOT}/apt"
FILES_DIR="${MIRROR_ROOT}/files"
APT_PORT=8080
FILES_PORT=8081

# ── MUST match wazuh_version in group_vars/all.yml ───────────────────────────
WAZUH_VERSION="4.14.5"

# Ubuntu codename of your VM templates (jammy=22.04, focal=20.04, noble=24.04)
UBUNTU_CODENAME="jammy"

# -----------------------------------------------------------------------------
phase_download() {
  echo "═══ PHASE A — Downloading all packages (needs internet) ═══"
  mkdir -p "${APT_DIR}/pool" "${FILES_DIR}/blue-apps/pip"

  echo "── Adding Wazuh apt repo key + repo (temporarily) ──"
  curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --dearmor | \
    sudo tee /usr/share/keyrings/wazuh.gpg > /dev/null
  echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" | \
    sudo tee /etc/apt/sources.list.d/wazuh.list > /dev/null

  sudo apt-get update

  echo "── Downloading .deb packages WITH all dependencies ──"
  cd "${APT_DIR}/pool"

  # Helper: download a package and everything it depends on
  dl() {
    echo "   → $1"
    apt-get download $(apt-cache depends --recurse --no-recommends --no-suggests \
      --no-conflicts --no-breaks --no-replaces --no-enhances \
      "$1" 2>/dev/null | grep "^\w" | sort -u) 2>/dev/null || true
    apt-get download "$1" 2>/dev/null || true
  }

  # ── Base utilities ────────────────────────────────────────────────────────
  dl curl
  dl gnupg
  dl gnupg2
  dl apt-transport-https
  dl lsb-release
  dl ufw
  dl unzip
  dl openssl
  dl sshpass
  dl jq

  # ── Python ───────────────────────────────────────────────────────────────
  dl python3
  dl python3-pip
  dl python3-venv
  dl python3-requests    # for blue-agent-linux (avoids pip version conflict)
  dl python3-pymysql     # for db-server MariaDB management

  # ── Web / App server ─────────────────────────────────────────────────────
  dl apache2
  dl apache2-utils
  dl php
  dl libapache2-mod-php
  dl php-mysql
  dl php-cli
  dl php-mbstring
  dl php-xml
  dl php-curl

  # ── Database ─────────────────────────────────────────────────────────────
  dl mariadb-server
  dl mariadb-client
  dl mysql-server

  # ── FTP ──────────────────────────────────────────────────────────────────
  dl vsftpd

  # ── Blue team Linux tools ─────────────────────────────────────────────────
  dl nmap
  dl wireshark
  dl arp-scan

  # ── Wazuh stack ──────────────────────────────────────────────────────────
  dl wazuh-manager
  dl wazuh-agent
  dl wazuh-indexer
  dl wazuh-dashboard
  dl filebeat

  echo "── Building apt repo index (Packages + Packages.gz) ──"
  cd "${APT_DIR}"
  dpkg-scanpackages pool /dev/null 2>/dev/null | gzip -9c > pool/Packages.gz
  dpkg-scanpackages pool /dev/null 2>/dev/null > pool/Packages

  echo "── Downloading standalone files ──"
  cd "${FILES_DIR}"

  # Wazuh Windows agent MSI — version must match group_vars/all.yml
  echo "   → wazuh-agent MSI (${WAZUH_VERSION})"
  curl -sLO "https://packages.wazuh.com/4.x/windows/wazuh-agent-${WAZUH_VERSION}-1.msi"

  # Wazuh certs tool + config
  echo "   → wazuh-certs-tool.sh"
  curl -sLO "https://packages.wazuh.com/4.7/wazuh-certs-tool.sh"
  curl -sLO "https://packages.wazuh.com/4.7/config.yml"

  # Wazuh filebeat module
  echo "   → wazuh-filebeat module"
  curl -sLO "https://packages.wazuh.com/4.x/filebeat/wazuh-filebeat-0.4.tar.gz"

  # ── Blue team Windows apps ────────────────────────────────────────────────
  echo "── Downloading Blue Team Windows apps ──"
  mkdir -p "${FILES_DIR}/blue-apps"
  cd "${FILES_DIR}/blue-apps"

  # Python for Windows
  echo "   → Python 3.11.9"
  curl -sLO "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"

  # Wireshark
  echo "   → Wireshark"
  curl -sLO "https://www.wireshark.org/download/win64/Wireshark-4.6.5-x64.exe"

  # Nmap/Zenmap
  echo "   → Nmap"
  curl -sLO "https://nmap.org/dist/nmap-7.94-setup.exe"

  # Burp Suite Community
  echo "   → Burp Suite Community"
  curl -sLo "burpsuite_community_windows-x64.exe" \
    "https://portswigger-cdn.net/burp/releases/download?product=community&type=WindowsX64"

  # Angry IP Scanner
  echo "   → Angry IP Scanner"
  curl -sLO "https://github.com/angryip/ipscan/releases/download/3.9.1/ipscan-3.9.1-setup.exe"

  # pip wheel for requests (Windows blue agent)
  echo "   → requests pip wheel"
  pip3 download -d "${FILES_DIR}/blue-apps/pip" requests 2>/dev/null || \
    echo "   (pip download skipped — install python3-pip first if needed)"

  # Clean up the temporary wazuh repo we added
  sudo rm -f /etc/apt/sources.list.d/wazuh.list /usr/share/keyrings/wazuh.gpg

  echo ""
  echo "✔ PHASE A complete. Mirror contents:"
  echo "  APT packages  → ${APT_DIR}/pool/"
  echo "  Wazuh files   → ${FILES_DIR}/"
  echo "  Windows apps  → ${FILES_DIR}/blue-apps/"
  echo "  pip wheels    → ${FILES_DIR}/blue-apps/pip/"
  echo ""
  echo "  If this is a different machine, copy ${MIRROR_ROOT} to the Terraform"
  echo "  server at the same path, then run:  sudo $0 serve"
}

# -----------------------------------------------------------------------------
phase_serve() {
  echo "═══ PHASE B — Starting offline mirror servers ═══"

  if [ ! -d "${APT_DIR}/pool" ]; then
    echo "✘ ${APT_DIR}/pool not found. Run '$0 download' first."
    exit 1
  fi

  echo "── Creating systemd service: offline-apt-mirror (port ${APT_PORT}) ──"
  sudo tee /etc/systemd/system/offline-apt-mirror.service > /dev/null << EOF
[Unit]
Description=Offline APT Mirror (CyberRange)
After=network.target

[Service]
Type=simple
WorkingDirectory=${APT_DIR}
ExecStart=/usr/bin/python3 -m http.server ${APT_PORT}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

  echo "── Creating systemd service: offline-files-mirror (port ${FILES_PORT}) ──"
  sudo tee /etc/systemd/system/offline-files-mirror.service > /dev/null << EOF
[Unit]
Description=Offline Files Mirror (CyberRange)
After=network.target

[Service]
Type=simple
WorkingDirectory=${FILES_DIR}
ExecStart=/usr/bin/python3 -m http.server ${FILES_PORT}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable --now offline-apt-mirror.service
  sudo systemctl enable --now offline-files-mirror.service

  IP=$(hostname -I | awk '{print $1}')
  echo ""
  echo "✔ PHASE B complete. Offline mirrors are LIVE:"
  echo "  APT mirror   → http://${IP}:${APT_PORT}"
  echo "  Files mirror → http://${IP}:${FILES_PORT}"
  echo ""
  echo "  Verify:"
  echo "    curl -s http://${IP}:${APT_PORT}/pool/Packages.gz --output /dev/null && echo OK"
  echo "    curl -I http://${IP}:${FILES_PORT}/wazuh-agent-${WAZUH_VERSION}-1.msi"
  echo "    curl -I http://${IP}:${FILES_PORT}/blue-apps/python-3.11.9-amd64.exe"
  echo ""
  echo "  Set in ansible/group_vars/all.yml:"
  echo "    offline_repo_host: \"${IP}\""
}

# -----------------------------------------------------------------------------
case "${1:-}" in
  download) phase_download ;;
  serve)    phase_serve ;;
  all)      phase_download && phase_serve ;;
  *)
    echo "Usage: $0 {download|serve|all}"
    echo "  download  — PHASE A: grab all packages + files (needs internet)"
    echo "  serve     — PHASE B: start mirror HTTP servers (no internet needed)"
    echo "  all       — run both (use on a machine that has internet)"
    exit 1
    ;;
esac
