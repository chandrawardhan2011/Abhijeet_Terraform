# =============================================================================
# CyberRange SYN-01 — Windows Client Master Patch Script
# Patches ALL injected vulnerabilities on windows-1 (10.0.20.150)
# Run as Administrator
# =============================================================================

Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  CyberRange Windows Client — Master Patch" -ForegroundColor Cyan
Write-Host "=============================================" -ForegroundColor Cyan

$errors = 0

# ── 1. Weak Admin Password / labuser ─────────────────────────────────────────
Write-Host "`n[1/13] Patching Weak Admin Password..." -ForegroundColor Yellow
try {
    net user labuser /delete 2>$null
    net user guest /active:no 2>$null
    net accounts /minpwlen:14 /maxpwage:90 /minpwage:1 /uniquepw:10 2>$null
    Write-Host "[+] labuser deleted, guest disabled, password policy restored" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 2. RDP Brute Force ────────────────────────────────────────────────────────
Write-Host "`n[2/13] Patching RDP Brute Force..." -ForegroundColor Yellow
try {
    Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' `
        -Name 'UserAuthentication' -Value 1
    net accounts /lockoutthreshold:5 /lockoutduration:30 /lockoutwindow:30 2>$null
    net localgroup 'Remote Desktop Users' Everyone /delete 2>$null
    Write-Host "[+] NLA enabled, lockout policy restored, Everyone removed from RDP users" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 3. Pass-the-Hash / WDigest ────────────────────────────────────────────────
Write-Host "`n[3/13] Patching Pass-the-Hash / WDigest..." -ForegroundColor Yellow
try {
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" /v UseLogonCredential /t REG_DWORD /d 0 /f 2>$null
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v LmCompatibilityLevel /t REG_DWORD /d 5 /f 2>$null
    Set-SmbServerConfiguration -RequireSecuritySignature $true -Force -ErrorAction SilentlyContinue
    Set-SmbClientConfiguration -RequireSecuritySignature $true -Force -ErrorAction SilentlyContinue
    Write-Host "[+] WDigest disabled, NTLMv2-only, SMB signing re-enabled" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 4. UAC ────────────────────────────────────────────────────────────────────
Write-Host "`n[4/13] Re-enabling UAC..." -ForegroundColor Yellow
try {
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v EnableLUA /t REG_DWORD /d 1 /f 2>$null
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorAdmin /t REG_DWORD /d 2 /f 2>$null
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v ConsentPromptBehaviorUser /t REG_DWORD /d 3 /f 2>$null
    reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" /v PromptOnSecureDesktop /t REG_DWORD /d 1 /f 2>$null
    Write-Host "[+] UAC re-enabled (reboot required)" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 5. PowerShell Execution Policy ───────────────────────────────────────────
Write-Host "`n[5/13] Restoring PowerShell Execution Policy..." -ForegroundColor Yellow
try {
    Set-ExecutionPolicy RemoteSigned -Scope LocalMachine -Force
    Set-ExecutionPolicy RemoteSigned -Scope CurrentUser -Force
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell" /v ExecutionPolicy /t REG_SZ /d "RemoteSigned" /f 2>$null
    Write-Host "[+] ExecutionPolicy restored to RemoteSigned" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 6. LSASS Dump Protection ──────────────────────────────────────────────────
Write-Host "`n[6/13] Restoring LSASS Protection..." -ForegroundColor Yellow
try {
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v RunAsPPL /t REG_DWORD /d 1 /f 2>$null
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest" /v UseLogonCredential /t REG_DWORD /d 0 /f 2>$null
    Remove-Item "C:\Temp\dump_instructions.txt" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] LSASS PPL enabled, WDigest disabled (reboot required for PPL)" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 7. SMB Signing ────────────────────────────────────────────────────────────
Write-Host "`n[7/13] Restoring SMB Signing..." -ForegroundColor Yellow
try {
    Set-SmbServerConfiguration -RequireSecuritySignature $true -EnableSecuritySignature $true -Force
    Set-SmbClientConfiguration -RequireSecuritySignature $true -Force
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v RequireSecuritySignature /t REG_DWORD /d 1 /f 2>$null
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v EnableSecuritySignature /t REG_DWORD /d 1 /f 2>$null
    Write-Host "[+] SMB signing re-enabled" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 8. Local Admin Everyone ───────────────────────────────────────────────────
Write-Host "`n[8/13] Removing Everyone from Administrators..." -ForegroundColor Yellow
try {
    net localgroup Administrators Everyone /delete 2>$null
    net localgroup Administrators "Authenticated Users" /delete 2>$null
    net user labuser /delete 2>$null
    Remove-Item "C:\Temp\admin_users.txt" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] Everyone and Authenticated Users removed from Administrators" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 9. AppLocker ──────────────────────────────────────────────────────────────
Write-Host "`n[9/13] Re-enabling AppLocker..." -ForegroundColor Yellow
try {
    Set-Service -Name AppIDSvc -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service -Name AppIDSvc -ErrorAction SilentlyContinue
    Remove-Item "C:\Temp\applocker_info.txt" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] AppLocker service re-enabled" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 10. NetBIOS / LLMNR ───────────────────────────────────────────────────────
Write-Host "`n[10/13] Disabling NetBIOS and LLMNR..." -ForegroundColor Yellow
try {
    reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient" /v EnableMulticast /t REG_DWORD /d 0 /f 2>$null
    $adapters = Get-WmiObject Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled }
    foreach ($adapter in $adapters) { $adapter.SetTcpipNetbios(2) | Out-Null }
    Remove-Item "C:\Temp\netbios_info.txt" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] NetBIOS and LLMNR disabled" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 11. NTLM Relay ────────────────────────────────────────────────────────────
Write-Host "`n[11/13] Patching NTLM Relay..." -ForegroundColor Yellow
try {
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" /v LDAPServerIntegrity /t REG_DWORD /d 2 /f 2>$null
    reg add "HKLM\SYSTEM\CurrentControlSet\Services\NTDS\Parameters" /v LdapEnforceChannelBinding /t REG_DWORD /d 2 /f 2>$null
    reg add "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" /v LmCompatibilityLevel /t REG_DWORD /d 5 /f 2>$null
    Remove-Item "C:\Temp\ntlm_relay_info.txt" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] LDAP signing and channel binding enforced, NTLMv2-only" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 12. AutoRun ───────────────────────────────────────────────────────────────
Write-Host "`n[12/13] Disabling AutoRun..." -ForegroundColor Yellow
try {
    reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f 2>$null
    reg add "HKLM\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer" /v NoDriveTypeAutoRun /t REG_DWORD /d 255 /f 2>$null
    Remove-Item "C:\Temp\autorun.inf" -Force -ErrorAction SilentlyContinue
    Write-Host "[+] AutoRun disabled for all drive types" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── 13. Windows Update ────────────────────────────────────────────────────────
Write-Host "`n[13/13] Re-enabling Windows Update..." -ForegroundColor Yellow
try {
    Set-Service -Name wuauserv -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service -Name wuauserv -ErrorAction SilentlyContinue
    reg delete "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate" /f 2>$null
    Write-Host "[+] Windows Update re-enabled" -ForegroundColor Green
} catch { Write-Host "[!] $($_.Exception.Message)" -ForegroundColor Red; $errors++ }

# ── Summary ───────────────────────────────────────────────────────────────────
Write-Host ""
Write-Host "=============================================" -ForegroundColor Cyan
Write-Host "  Windows Client Patch Complete" -ForegroundColor Cyan
if ($errors -eq 0) {
    Write-Host "  All 13 patches applied successfully" -ForegroundColor Green
} else {
    Write-Host "  Completed with $errors error(s)" -ForegroundColor Yellow
}
Write-Host "  REMINDER: Reboot required for UAC and LSASS PPL changes" -ForegroundColor Yellow
Write-Host "  REMINDER: Change Administrator password if compromised" -ForegroundColor Yellow
Write-Host "=============================================" -ForegroundColor Cyan
