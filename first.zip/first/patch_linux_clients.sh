#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — Linux Client Master Patch Script
# Patches ALL injected vulnerabilities on:
#   linux-1 (10.0.20.200) — Ubuntu 22.04
# Run as root
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange Linux Client — Master Patch"
echo "============================================="

# ── 1. World-Writable Directories ────────────────────────────────────────────
info "[1/11] Patching World-Writable Directories..."
chmod 755 /opt/shared /srv/data /var/app 2>/dev/null || true
rm -f /opt/shared/internal_notes.txt
log "World-writable dirs fixed, sensitive files removed"

# ── 2. Weak Passwords ─────────────────────────────────────────────────────────
info "[2/11] Patching Weak User Passwords..."
for user in alice bob charlie david; do
    if id "$user" &>/dev/null; then
        passwd -l "$user" 2>/dev/null || true
        log "Locked: $user (set strong password manually)"
    fi
done
# Re-enable pam_pwquality
apt-get install -y libpam-pwquality 2>/dev/null || true
if ! grep -q "pam_pwquality" /etc/pam.d/common-password; then
    echo "password requisite pam_pwquality.so retry=3 minlen=12 dcredit=-1 ucredit=-1" \
        >> /etc/pam.d/common-password
fi
log "Password complexity re-enabled"

# ── 3. Unprotected SSH Keys ───────────────────────────────────────────────────
info "[3/11] Patching Unprotected SSH Keys..."
chmod 700 /home/ansible/.ssh 2>/dev/null || true
chmod 600 /home/ansible/.ssh/id_rsa 2>/dev/null || true
chmod 644 /home/ansible/.ssh/id_rsa.pub 2>/dev/null || true
chown -R ansible:ansible /home/ansible/.ssh 2>/dev/null || true
rm -f /tmp/admin_ssh_key /tmp/ssh_key_locations.txt
log "SSH key permissions fixed"

# ── 4. No Host Firewall ───────────────────────────────────────────────────────
info "[4/11] Restoring Host Firewall..."
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw --force enable
log "UFW re-enabled"

# ── 5. Kernel Hardening ───────────────────────────────────────────────────────
info "[5/11] Restoring Kernel Hardening..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sysctl -w kernel.kptr_restrict=1 2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1 2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
log "Kernel hardening restored"

# ── 6. Bash History ───────────────────────────────────────────────────────────
info "[6/11] Clearing Sensitive Bash History..."
truncate -s 0 /root/.bash_history 2>/dev/null || true
truncate -s 0 /home/ansible/.bash_history 2>/dev/null || true
log "Bash history cleared. Rotate Admin@123 password."

# ── 7. LXD Privesc ────────────────────────────────────────────────────────────
info "[7/11] Patching LXD Privilege Escalation..."
gpasswd -d lxduser lxd 2>/dev/null || true
gpasswd -d lxduser docker 2>/dev/null || true
userdel -r lxduser 2>/dev/null || true
rm -f /tmp/lxd_exploit_info.txt
log "lxduser removed from lxd/docker groups and deleted"

# ── 8. Exposed API Keys ───────────────────────────────────────────────────────
info "[8/11] Removing Exposed API Keys..."
sed -i '/AWS_ACCESS_KEY_ID/d;/AWS_SECRET_ACCESS_KEY/d;/GITHUB_TOKEN/d;/DATABASE_URL/d' \
    /etc/environment 2>/dev/null || true
rm -f /opt/.env
log "API keys removed from /etc/environment and /opt/.env. Revoke in AWS/GitHub."

# ── 9. Netcat Backdoor ────────────────────────────────────────────────────────
info "[9/11] Removing Netcat Backdoor..."
pkill -f 'nc -lvnp' 2>/dev/null || true
sed -i '/nc.*lvnp.*bash/d' /etc/crontab 2>/dev/null || true
crontab -l 2>/dev/null | grep -v "nc -lvnp" | crontab - 2>/dev/null || true
ufw deny 4444/tcp 2>/dev/null || true
ufw deny 1337/tcp 2>/dev/null || true
rm -f /tmp/backdoor_info.txt
log "Netcat backdoors killed and removed"

# ── 10. /etc/passwd World-Writable ───────────────────────────────────────────
info "[10/11] Fixing /etc/passwd and /etc/shadow..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
# Remove any rogue root-uid accounts
grep ':0:0:' /etc/passwd | grep -v '^root:' | cut -d: -f1 | while read u; do
    sed -i "/^${u}:/d" /etc/passwd
    log "Removed rogue account: $u"
done
rm -f /tmp/passwd_backup /tmp/shadow_backup
log "/etc/passwd and /etc/shadow permissions restored"

# ── 11. RPC Portmapper ────────────────────────────────────────────────────────
info "[11/11] Removing RPC Portmapper..."
systemctl stop rpcbind 2>/dev/null || true
systemctl disable rpcbind 2>/dev/null || true
ufw deny 111/tcp 2>/dev/null || true
ufw deny 111/udp 2>/dev/null || true
apt-get purge -y rpcbind nfs-common 2>/dev/null || true
log "rpcbind removed"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  Linux Client Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 11 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s)"
fi
echo "  REMINDER: Manually set strong passwords for:"
echo "    alice, bob, charlie, david, root, ansible"
echo "  REMINDER: Revoke AWS and GitHub keys"
echo "============================================="
