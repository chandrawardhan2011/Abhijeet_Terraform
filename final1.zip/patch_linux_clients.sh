#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — Linux Client Master Patch Script
# Target: linux-1 (10.0.20.200) — Ubuntu 22.04 Jammy
# Patches 18 injectable (SSH keys removed — breaks Ansible) vulnerabilities (scenario2linux has no patch)
# Run as root via Ansible script module
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange Linux Client — Master Patch"
echo "  Target: linux-1 (10.0.20.200)"
echo "============================================="

# ── PRE-FIX: Restore critical permissions so sudo works ──────────────────────
echo "[*] PRE-FIX: Restoring critical permissions before patching..."
chmod 440 /etc/sudoers 2>/dev/null || true
chmod 644 /etc/passwd  2>/dev/null || true
chmod 640 /etc/shadow  2>/dev/null && chown root:shadow /etc/shadow 2>/dev/null || true
chmod 600 /etc/crontab 2>/dev/null || true
echo "[+] PRE-FIX complete"

# ── 1. SSH Brute Force (LS01) ─────────────────────────────────────────────────
info "[1/18] Patching SSH Brute Force..."
sed -i 's/MaxAuthTries 100/MaxAuthTries 3/'                        /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/'  /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config 2>/dev/null || true
grep -q "^MaxAuthTries" /etc/ssh/sshd_config || echo "MaxAuthTries 3" >> /etc/ssh/sshd_config
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
rm -f /etc/sudoers.d/labuser
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
apt-get install -y fail2ban 2>/dev/null && systemctl enable --now fail2ban 2>/dev/null || true
rm -f /tmp/ssh_brute_info.txt
log "SSH patched — labuser removed, MaxAuthTries=3, fail2ban enabled"

# ── 2. Sudo Privilege Escalation (LS03) ──────────────────────────────────────
info "[2/18] Patching SUDO Privilege Escalation..."
sed -i '/student.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
rm -f /etc/sudoers.d/vuln_* /etc/sudoers.d/student /etc/sudoers.d/labuser
userdel -r student 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
chmod 440 /etc/sudoers
rm -f /tmp/sudo_privesc_info.txt
log "SUDO NOPASSWD entries removed, student and labuser deleted"

# ── 3. SUID Binary Misconfiguration (LS09) ───────────────────────────────────
info "[3/18] Patching SUID Binaries..."
rm -f /tmp/bash_suid /tmp/find_suid /tmp/python3_suid /tmp/suid_vulns.txt
log "SUID artefacts removed from /tmp"

# ── 4. NFS no_root_squash (LS10) ─────────────────────────────────────────────
info "[4/18] Patching NFS Misconfiguration..."
if [ -f /etc/exports ]; then
    sed -i 's/no_root_squash/root_squash/g' /etc/exports 2>/dev/null || true
    exportfs -ra 2>/dev/null || true
    systemctl restart nfs-kernel-server 2>/dev/null || true
    rm -f /srv/nfs_share/sensitive_data.txt
    log "NFS no_root_squash removed"
else
    log "NFS not configured — skipping"
fi

# ── 5. Plaintext Credentials in Config (LS11) ────────────────────────────────
info "[5/18] Patching Plaintext Credentials..."
rm -f /opt/app/config/database.conf /opt/app/config/app.env /opt/.env
truncate -s 0 /var/log/app/app.log 2>/dev/null || true
log "Plaintext config files removed"

# ── 6. Unnecessary Open Ports / No Firewall (LS12) ───────────────────────────
info "[6/18] Patching Open Ports and Firewall..."
pkill -f 'nc -lvnp' 2>/dev/null || true
apt-get purge -y telnetd 2>/dev/null || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw deny 4444/tcp
ufw deny 8888/tcp
ufw deny 1337/tcp
ufw --force enable
log "UFW enabled, netcat listeners killed, ports 4444/8888/1337 blocked"

# ── 7. Log Tampering / Audit Disabled (LS13) ─────────────────────────────────
info "[7/18] Patching Log Tampering..."
chmod 755 /var/log
chmod 640 /var/log/auth.log 2>/dev/null && chown syslog:adm /var/log/auth.log 2>/dev/null || true
chmod 640 /var/log/syslog   2>/dev/null && chown syslog:adm /var/log/syslog   2>/dev/null || true
apt-get install -y auditd 2>/dev/null || true
systemctl enable --now auditd  2>/dev/null || true
systemctl enable --now rsyslog 2>/dev/null || true
log "Log permissions fixed, auditd and rsyslog re-enabled"

# ── 8. Weak User Passwords (LC05) ────────────────────────────────────────────
info "[8/18] Patching Weak User Passwords..."
for user in alice bob charlie david; do
    if id "$user" &>/dev/null; then
        userdel -r "$user" 2>/dev/null || true
        log "Deleted: $user"
    fi
done
apt-get install -y libpam-pwquality 2>/dev/null || true
sed -i 's/^# password requisite pam_pwquality/password requisite pam_pwquality/' \
    /etc/pam.d/common-password 2>/dev/null || true
if ! grep -q "pam_pwquality" /etc/pam.d/common-password 2>/dev/null; then
    echo "password requisite pam_pwquality.so retry=3 minlen=12 dcredit=-1 ucredit=-1" \
        >> /etc/pam.d/common-password
fi
log "Weak accounts locked, password complexity restored"


# ── 10. No Host Firewall (LC07) ───────────────────────────────────────────────
info "[9/18] Restoring Host Firewall..."
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw --force enable
log "UFW re-enabled with default deny incoming"

# ── 11. Kernel Hardening Disabled (LC08) ─────────────────────────────────────
info "[10/18] Patching Kernel Hardening..."
sysctl -w kernel.randomize_va_space=2          2>/dev/null || true
sysctl -w kernel.kptr_restrict=1               2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1           2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1            2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
sed -i '/accept_redirects = 1/d;/tcp_syncookies = 0/d' /etc/sysctl.conf 2>/dev/null || true
rm -f /tmp/kernel_vuln_info.txt
log "Kernel hardening restored"

# ── 12. Sensitive Data in Bash History (LC09) ────────────────────────────────
info "[11/18] Clearing Sensitive Bash History..."
truncate -s 0 /root/.bash_history         2>/dev/null || true
truncate -s 0 /home/ansible/.bash_history 2>/dev/null || true
for u in alice bob charlie david student labuser; do
    [ -f "/home/$u/.bash_history" ] && truncate -s 0 /home/$u/.bash_history 2>/dev/null || true
done
log "Bash history cleared for all users"

# ── 13. LXD Group Privilege Escalation (LC10) ────────────────────────────────
info "[12/18] Patching LXD Privilege Escalation..."
gpasswd -d lxduser lxd    2>/dev/null || true
gpasswd -d lxduser docker 2>/dev/null || true
userdel -r lxduser 2>/dev/null || true
rm -f /tmp/lxd_exploit_info.txt
log "lxduser removed from lxd/docker groups and deleted"

# ── 14. Exposed API Keys in Environment (LC11) ───────────────────────────────
info "[13/18] Removing Exposed API Keys..."
sed -i '/AWS_ACCESS_KEY_ID/d;/AWS_SECRET_ACCESS_KEY/d;/GITHUB_TOKEN/d' /etc/environment 2>/dev/null || true
sed -i '/DATABASE_URL/d;/SECRET_KEY/d;/REDIS_URL/d'                    /etc/environment 2>/dev/null || true
rm -f /opt/.env
log "API keys removed — REMINDER: revoke in AWS/GitHub"

# ── 15. Netcat Backdoor 4444/1337 (LC12) ─────────────────────────────────────
info "[14/18] Removing Netcat Backdoor..."
pkill -f 'nc -lvnp' 2>/dev/null || true
pkill -f 'nohup nc'  2>/dev/null || true
sed -i '/nc.*lvnp.*bash/d;/nohup nc.*4444/d;/nohup nc.*1337/d' /etc/crontab 2>/dev/null || true
crontab -l 2>/dev/null | grep -v "nc -lvnp\|nohup nc" | crontab - 2>/dev/null || true
ufw deny 4444/tcp 2>/dev/null || true
ufw deny 1337/tcp 2>/dev/null || true
rm -f /tmp/backdoor_info.txt
log "Netcat backdoors killed, ports 4444/1337 blocked"

# ── 16. World Writable passwd/shadow (LC13) ──────────────────────────────────
info "[15/18] Fixing /etc/passwd and /etc/shadow..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
grep ':0:0:' /etc/passwd | grep -v '^root:' | cut -d: -f1 | while read u; do
    sed -i "/^${u}:/d" /etc/passwd
    log "Removed rogue root account: $u"
done
rm -f /tmp/passwd_backup /tmp/shadow_backup
log "/etc/passwd (644) and /etc/shadow (640) restored"

# ── 17. Dirty COW / ASLR Disabled (LC01) ─────────────────────────────────────
info "[16/18] Patching Dirty COW / ASLR..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sed -i '/randomize_va_space\s*=\s*0/d' /etc/sysctl.conf 2>/dev/null || true
grep -q "^kernel.randomize_va_space" /etc/sysctl.conf || \
    echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
rm -f /tmp/vuln_suid_bash /tmp/root_owned_writable /tmp/dirty_cow_vulnerable
log "ASLR re-enabled, Dirty COW artifacts removed"

# ── 18. Writable Cron Jobs (LC04) ────────────────────────────────────────────
info "[17/18] Patching Writable Cron Jobs..."
chmod 755 /opt/cleanup.sh 2>/dev/null && chown root:root /opt/cleanup.sh 2>/dev/null || true
chmod 600 /etc/crontab    2>/dev/null || true
rm -f /etc/cron.d/vuln_cleanup
crontab -l 2>/dev/null | grep -v "cleanup.sh\|bash -i\|/dev/tcp" | crontab - 2>/dev/null || true
sed -i '/cleanup\.sh/d;/bash.*\/dev\/tcp/d' /etc/crontab 2>/dev/null || true
log "Crontab permissions fixed, vuln entries removed"

# ── 19. RPC Portmapper Exposed (LC14) ────────────────────────────────────────
info "[18/18] Disabling RPC Portmapper..."
systemctl stop rpcbind    2>/dev/null || true
systemctl disable rpcbind 2>/dev/null || true
systemctl mask rpcbind    2>/dev/null || true
pkill -f rpcbind          2>/dev/null || true
ufw deny 111/tcp          2>/dev/null || true
ufw deny 111/udp          2>/dev/null || true
ufw --force enable        2>/dev/null || true
log "rpcbind stopped, masked, port 111 blocked"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  Linux Client Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 18 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s) — review output above"
fi
echo "  REMINDER: Set strong passwords for:"
echo "    alice, bob, charlie, david, root, ansible"
echo "  REMINDER: Revoke AWS and GitHub keys manually"
echo "============================================="
