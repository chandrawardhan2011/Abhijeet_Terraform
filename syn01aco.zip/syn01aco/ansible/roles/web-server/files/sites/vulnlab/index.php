<?php
/**
 * Front controller. Reads the state file, routes vuln requests to the
 * right handler in the right mode (vuln or patched), and renders the lab
 * page when no vuln is specified.
 *
 * Request shapes:
 *   GET  /              -> render lab page for current level
 *   GET  /?vuln=sqli&q=x -> run sqli handler, return its HTML fragment
 *   POST /?vuln=xss     -> same but for POST bodies
 */

require __DIR__ . '/config.php';

init_lab();

$state = get_state();
$level = $state['level'];
$vuln  = $_REQUEST['vuln'] ?? null;

if (!$vuln) {
    include __DIR__ . '/views/lab.php';
    exit;
}

if (!in_array($vuln, VULNS, true)) {
    http_response_code(404);
    exit('Unknown vuln');
}

require __DIR__ . "/handlers/$vuln.php";

$mode = is_open($level, $vuln) ? 'vuln' : 'patched';
$fn   = "{$vuln}_{$level}_{$mode}";

if (!function_exists($fn)) {
    http_response_code(500);
    exit("Missing handler: $fn");
}

echo $fn();
