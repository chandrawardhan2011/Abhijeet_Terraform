Write-Host "[VULN] Configuring weak password policy..."

$Role = (Get-CimInstance Win32_ComputerSystem).DomainRole
$IsDC = ($Role -ge 4)

if ($IsDC)
{
    Write-Host "[*] Domain Controller detected"

    net user Administrator Admin
    net user Guest guest

    net accounts /minpwlen:1
    net accounts /uniquepw:0
    net accounts /maxpwage:unlimited
    net accounts /minpwage:0

    Write-Host "[+] Weak DOMAIN password policy applied"
}
else
{
    Write-Host "[*] Workstation detected"

    net user Administrator Admin
    net user Guest guest

    net accounts /minpwlen:1
    net accounts /uniquepw:0
    net accounts /maxpwage:unlimited
    net accounts /minpwage:0

    try
    {
        Get-LocalUser Administrator | Set-LocalUser -PasswordNeverExpires $true
    }
    catch {}

    Write-Host "[+] Weak LOCAL password policy applied"
}

Write-Host "[SUCCESS] Administrator password = Admin"