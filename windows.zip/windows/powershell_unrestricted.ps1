# vuln: powershell_unrestricted | severity: high

Write-Host "[VULN] Setting PowerShell to Unrestricted execution policy..."

Set-ExecutionPolicy Unrestricted -Scope LocalMachine -Force
Set-ExecutionPolicy Bypass -Scope CurrentUser -Force

reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell" /v EnableScripts /t REG_DWORD /d 1 /f
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\PowerShell" /v ExecutionPolicy /t REG_SZ /d "Unrestricted" /f

Write-Host "[VULN] PowerShell execution policy set to Unrestricted."