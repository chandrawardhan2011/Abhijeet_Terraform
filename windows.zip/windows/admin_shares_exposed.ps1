# vuln: admin_shares_exposed | severity: medium

Write-Host "[VULN] Exposing administrative shares..."

# Create temp folder if needed
New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null

# Detect machine role
$Role = (Get-CimInstance Win32_ComputerSystem).DomainRole
$IsDC = ($Role -ge 4)

# Enable automatic admin shares
reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" `
    /v AutoShareServer `
    /t REG_DWORD `
    /d 1 `
    /f

reg add "HKLM\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" `
    /v AutoShareWks `
    /t REG_DWORD `
    /d 1 `
    /f

# Restart SMB service
Restart-Service LanmanServer -Force -ErrorAction SilentlyContinue

if ($IsDC)
{
    Write-Host "[*] Domain Controller detected"

    # Create a deliberately exposed SYSVOL share
    if (Test-Path "C:\Windows\SYSVOL")
    {
        New-SmbShare `
            -Name "NETLOGON_BACKUP" `
            -Path "C:\Windows\SYSVOL" `
            -FullAccess "Everyone" `
            -ErrorAction SilentlyContinue
    }

    Set-Content `
        -Path "C:\Temp\ad14_info.txt" `
        -Value @"
Administrative Shares Exposure

Machine Type : Domain Controller

Exposed Share:
NETLOGON_BACKUP -> C:\Windows\SYSVOL

Risk:
Sensitive domain data exposed through weak share permissions.
"@
}
else
{
    Write-Host "[*] Workstation detected"

    # Universal share for clients
    New-SmbShare `
        -Name "PUBLIC_DATA" `
        -Path "C:\Users\Public" `
        -FullAccess "Everyone" `
        -ErrorAction SilentlyContinue

    Set-Content `
        -Path "C:\Temp\ad14_info.txt" `
        -Value @"
Administrative Shares Exposure

Machine Type : Workstation

Exposed Share:
PUBLIC_DATA -> C:\Users\Public

Risk:
Files accessible through weak share permissions.
"@
}

Write-Host "[VULN] Administrative shares exposed."