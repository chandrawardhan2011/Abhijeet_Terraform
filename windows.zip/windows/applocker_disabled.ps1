# vuln: applocker_disabled | severity: medium

Write-Host "[VULN] Disabling AppLocker and Application Control..."

if (!(Test-Path "C:\Temp"))
{
    New-Item -ItemType Directory -Path "C:\Temp" -Force | Out-Null
}

# Disable AppLocker service
Set-Service -Name AppIDSvc -StartupType Disabled -ErrorAction SilentlyContinue
Stop-Service -Name AppIDSvc -Force -ErrorAction SilentlyContinue

# Disable WDAC policy flag (lab simulation)
reg add "HKLM\SYSTEM\CurrentControlSet\Control\CI\Policy" `
    /v VerifiedAndReputablePolicyState `
    /t REG_DWORD `
    /d 0 `
    /f

Set-Content `
    -Path "C:\Temp\applocker_info.txt" `
    -Value "AppLocker disabled.`nApplication control protections reduced."

Write-Host "[VULN] AppLocker disabled - any binary can execute without restriction."