#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — FTP Server Patch Script
# Target: ftp-server-1 (10.0.20.40) — vsftpd
# Patches: 13 common server vulns + 1 ftp-specific (ftp_anonymous)
# Run as root
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange — FTP Server Patch"
echo "  Target: ftp-server-1 (vsftpd)"
echo "============================================="

# ── 1. SSH Brute Force ────────────────────────────────────────────────────────
info "[1/14] Patching SSH Brute Force..."
sed -i 's/MaxAuthTries 100/MaxAuthTries 3/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config 2>/dev/null || true
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
rm -f /etc/sudoers.d/labuser /tmp/ssh_brute_info.txt
apt-get install -y fail2ban 2>/dev/null && systemctl enable --now fail2ban 2>/dev/null || true
log "labuser removed, MaxAuthTries=3, fail2ban enabled"

# ── 2. Dirty COW / ASLR ──────────────────────────────────────────────────────
info "[2/14] Patching Dirty COW / ASLR..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sed -i '/randomize_va_space\s*=\s*0/d' /etc/sysctl.conf 2>/dev/null || true
echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
rm -f /tmp/vuln_suid_bash /tmp/root_owned_writable /tmp/dirty_cow_vulnerable
log "ASLR re-enabled"

# ── 3. SUDO Privilege Escalation ─────────────────────────────────────────────
info "[3/14] Patching SUDO Privilege Escalation..."
sed -i '/student.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
rm -f /etc/sudoers.d/vuln_* /etc/sudoers.d/student
userdel -r student 2>/dev/null || true
chmod 440 /etc/sudoers
log "NOPASSWD sudoers entries removed"

# ── 4. Cronjob Misconfiguration ───────────────────────────────────────────────
info "[4/14] Patching Cronjob Misconfiguration..."
chmod 755 /opt/cleanup.sh 2>/dev/null && chown root:root /opt/cleanup.sh 2>/dev/null || true
chmod 600 /etc/crontab 2>/dev/null || true
rm -f /etc/cron.d/vuln_cleanup
crontab -l 2>/dev/null | grep -v "bash -i\|nc -lvnp\|/dev/tcp" | crontab - 2>/dev/null || true
sed -i '/bash.*\/dev\/tcp/d' /etc/crontab 2>/dev/null || true
log "Cron permissions fixed, reverse-shell entries removed"

# ── 5. Weak File Permissions ──────────────────────────────────────────────────
info "[5/14] Patching Weak File Permissions..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
chmod 440 /etc/sudoers
chmod 600 /etc/crontab
find /opt -name "*.conf" -exec chmod 640 {} \; 2>/dev/null || true
rm -f /tmp/shadow_backup /tmp/permissions_backup
log "File permissions restored"

# ── 6. Kernel Hardening ───────────────────────────────────────────────────────
info "[6/14] Patching Kernel Hardening..."
sysctl -w kernel.randomize_va_space=2   2>/dev/null || true
sysctl -w kernel.kptr_restrict=1        2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1    2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1     2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
rm -f /tmp/kernel_vuln_info.txt
log "Kernel hardening restored"

# ── 7. SUID Binaries ──────────────────────────────────────────────────────────
info "[7/14] Patching SUID Binaries..."
rm -f /tmp/bash_suid /tmp/find_suid /tmp/python3_suid /tmp/suid_vulns.txt
log "SUID artefacts removed"

# ── 8. NFS Misconfiguration ───────────────────────────────────────────────────
info "[8/14] Patching NFS Misconfiguration..."
if [ -f /etc/exports ]; then
    sed -i 's/no_root_squash/root_squash/g' /etc/exports 2>/dev/null || true
    exportfs -ra 2>/dev/null || true
    systemctl restart nfs-kernel-server 2>/dev/null || true
    rm -f /srv/nfs_share/sensitive_data.txt
    log "NFS no_root_squash removed"
else
    log "NFS not configured on this host — skipping"
fi

# ── 9. Plaintext Credentials ─────────────────────────────────────────────────
info "[9/14] Patching Plaintext Credentials..."
rm -f /opt/app/config/database.conf /opt/app/config/app.env /opt/.env
# Remove exposed credential files from FTP pub directory
rm -f /var/ftp/pub/credentials.txt /var/ftp/pub/network_diagram.txt \
      /home/ftp/credentials.txt /srv/ftp/credentials.txt
truncate -s 0 /var/log/app/app.log 2>/dev/null || true
log "Plaintext credential files removed from FTP directories and config"

# ── 10. Open Ports / Firewall ─────────────────────────────────────────────────
info "[10/14] Patching Open Ports and Firewall..."
pkill -f 'nc -lvnp' 2>/dev/null || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 21/tcp          # FTP control
ufw allow 20/tcp          # FTP data
ufw allow 10090:10100/tcp # FTP passive port range (common vsftpd default)
ufw deny 4444/tcp
ufw deny 8888/tcp
ufw --force enable
log "UFW enabled: 22/21/20/passive-range allowed, 4444/8888 blocked"

# ── 11. Log Tampering ─────────────────────────────────────────────────────────
info "[11/14] Patching Log Tampering..."
chmod 755 /var/log
chmod 640 /var/log/auth.log    2>/dev/null && chown syslog:adm /var/log/auth.log    2>/dev/null || true
chmod 640 /var/log/syslog      2>/dev/null && chown syslog:adm /var/log/syslog      2>/dev/null || true
chmod 640 /var/log/vsftpd.log  2>/dev/null && chown root:adm  /var/log/vsftpd.log  2>/dev/null || true
apt-get install -y auditd 2>/dev/null || true
systemctl enable --now auditd  2>/dev/null || true
systemctl enable --now rsyslog 2>/dev/null || true
log "Log permissions fixed, auditd and rsyslog re-enabled"

# ── 12. Apache check (not expected on ftp-server) ────────────────────────────
info "[12/14] Apache check..."
if systemctl is-active --quiet apache2 2>/dev/null; then
    sed -i 's/ServerTokens Full/ServerTokens Prod/'    /etc/apache2/apache2.conf 2>/dev/null || true
    sed -i 's/ServerSignature On/ServerSignature Off/' /etc/apache2/apache2.conf 2>/dev/null || true
    systemctl restart apache2 2>/dev/null || true
    log "Apache found and hardened"
else
    log "Apache not running on ftp-server — skipping"
fi

# ── 13. MySQL check (not expected on ftp-server) ─────────────────────────────
info "[13/14] MySQL check..."
if systemctl is-active --quiet mariadb 2>/dev/null || systemctl is-active --quiet mysql 2>/dev/null; then
    mysql -u root -proot -e "DROP USER IF EXISTS 'root'@'%'; DROP USER IF EXISTS 'admin'@'%'; FLUSH PRIVILEGES;" 2>/dev/null || true
    log "MySQL remote accounts cleaned up"
else
    log "MySQL/MariaDB not running on ftp-server — skipping"
fi

# ── 14. [FTP-SPECIFIC] Anonymous FTP Login ───────────────────────────────────
info "[14/14] Patching FTP Anonymous Login..."
if systemctl is-active --quiet vsftpd 2>/dev/null || [ -f /etc/vsftpd.conf ]; then
    # Disable anonymous access
    sed -i 's/anonymous_enable=YES/anonymous_enable=NO/'   /etc/vsftpd.conf 2>/dev/null || true
    sed -i 's/no_anon_password=YES/no_anon_password=NO/'   /etc/vsftpd.conf 2>/dev/null || true
    sed -i 's/anon_upload_enable=YES/anon_upload_enable=NO/' /etc/vsftpd.conf 2>/dev/null || true
    sed -i 's/anon_mkdir_write_enable=YES/anon_mkdir_write_enable=NO/' /etc/vsftpd.conf 2>/dev/null || true

    # Ensure these secure settings are present
    grep -q "^anonymous_enable" /etc/vsftpd.conf || echo "anonymous_enable=NO" >> /etc/vsftpd.conf
    grep -q "^local_enable"     /etc/vsftpd.conf || echo "local_enable=YES"    >> /etc/vsftpd.conf
    grep -q "^chroot_local_user" /etc/vsftpd.conf || echo "chroot_local_user=YES" >> /etc/vsftpd.conf

    # Remove credential files left by injection
    rm -f /var/ftp/pub/credentials.txt \
          /var/ftp/pub/network_diagram.txt \
          /home/ftp/credentials.txt \
          /srv/ftp/credentials.txt

    # Fix ownership of FTP root
    chown root:root /var/ftp 2>/dev/null || true
    chmod 755 /var/ftp 2>/dev/null || true

    systemctl restart vsftpd 2>/dev/null || true
    log "vsftpd: anonymous login disabled, credentials.txt removed, chroot enabled"
else
    err "vsftpd not found on this host — cannot patch FTP anonymous login"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  FTP Server Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 14 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s) — review output above"
fi
echo "  REMINDER: Set strong passwords for all FTP user accounts"
echo "  REMINDER: Consider switching to SFTP (openssh) for secure file transfer"
echo "============================================="
