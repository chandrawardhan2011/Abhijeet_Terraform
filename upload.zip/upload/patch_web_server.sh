#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — Web Server Patch Script
# Target: web-server-1 (10.0.20.21) — Apache + VulnLab
# Patches: 13 common server vulns + 1 web-specific (insecure_service_config)
# Run as root
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange — Web Server Patch"
echo "  Target: web-server-1 (Apache + VulnLab)"
echo "============================================="

# ── 1. SSH Brute Force ────────────────────────────────────────────────────────
info "[1/14] Patching SSH Brute Force..."
sed -i 's/MaxAuthTries 100/MaxAuthTries 3/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config 2>/dev/null || true
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
rm -f /etc/sudoers.d/labuser /tmp/ssh_brute_info.txt
apt-get install -y fail2ban 2>/dev/null && systemctl enable --now fail2ban 2>/dev/null || true
log "labuser removed, MaxAuthTries=3, PasswordAuth off, fail2ban enabled"

# ── 2. Dirty COW / ASLR ──────────────────────────────────────────────────────
info "[2/14] Patching Dirty COW / ASLR..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sed -i '/randomize_va_space\s*=\s*0/d' /etc/sysctl.conf 2>/dev/null || true
echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
rm -f /tmp/vuln_suid_bash /tmp/root_owned_writable /tmp/dirty_cow_vulnerable
log "ASLR re-enabled (randomize_va_space=2)"

# ── 3. SUDO Privilege Escalation ─────────────────────────────────────────────
info "[3/14] Patching SUDO Privilege Escalation..."
sed -i '/student.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
rm -f /etc/sudoers.d/vuln_* /etc/sudoers.d/student
userdel -r student 2>/dev/null || true
chmod 440 /etc/sudoers
log "NOPASSWD sudoers entries removed, student user deleted"

# ── 4. Cronjob Misconfiguration ───────────────────────────────────────────────
info "[4/14] Patching Cronjob Misconfiguration..."
chmod 755 /opt/cleanup.sh 2>/dev/null && chown root:root /opt/cleanup.sh 2>/dev/null || true
chmod 600 /etc/crontab 2>/dev/null || true
rm -f /etc/cron.d/vuln_cleanup
crontab -l 2>/dev/null | grep -v "bash -i\|nc -lvnp\|/dev/tcp" | crontab - 2>/dev/null || true
sed -i '/bash.*\/dev\/tcp/d' /etc/crontab 2>/dev/null || true
log "Cron permissions fixed, reverse-shell entries removed"

# ── 5. Weak File Permissions ──────────────────────────────────────────────────
info "[5/14] Patching Weak File Permissions..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
chmod 440 /etc/sudoers
chmod 600 /etc/crontab
find /home -name "*.sh" -exec chmod 750 {} \; 2>/dev/null || true
find /opt -name "*.conf" -exec chmod 640 {} \; 2>/dev/null || true
rm -f /tmp/shadow_backup /tmp/permissions_backup
log "File permissions restored (/etc/passwd 644, /etc/shadow 640)"

# ── 6. Kernel Hardening ───────────────────────────────────────────────────────
info "[6/14] Patching Kernel Hardening..."
sysctl -w kernel.randomize_va_space=2   2>/dev/null || true
sysctl -w kernel.kptr_restrict=1        2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1    2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1     2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
rm -f /tmp/kernel_vuln_info.txt
log "Kernel hardening restored"

# ── 7. SUID Binaries ──────────────────────────────────────────────────────────
info "[7/14] Patching SUID Binaries..."
rm -f /tmp/bash_suid /tmp/find_suid /tmp/python3_suid /tmp/suid_vulns.txt
# Restore correct permissions if copies were made
chmod 755 /bin/bash 2>/dev/null || true
log "SUID artefacts removed from /tmp"

# ── 8. NFS Misconfiguration ───────────────────────────────────────────────────
info "[8/14] Patching NFS Misconfiguration..."
if [ -f /etc/exports ]; then
    sed -i 's/no_root_squash/root_squash/g' /etc/exports 2>/dev/null || true
    exportfs -ra 2>/dev/null || true
    systemctl restart nfs-kernel-server 2>/dev/null || true
    rm -f /srv/nfs_share/sensitive_data.txt
    log "NFS no_root_squash removed"
else
    log "NFS not configured on this host — skipping"
fi

# ── 9. Plaintext Credentials ─────────────────────────────────────────────────
info "[9/14] Patching Plaintext Credentials..."
rm -f /opt/app/config/database.conf /opt/app/config/app.env /opt/.env
truncate -s 0 /var/log/app/app.log 2>/dev/null || true
# Remove any hardcoded DB creds from PHP config
find /var/www -name "*.php" -exec grep -l "Admin@123\|password123\|P@ssw0rd" {} \; 2>/dev/null | \
    while read f; do
        sed -i "s/Admin@123/PATCHED_ROTATE_ME/g;s/password123/PATCHED_ROTATE_ME/g" "$f" 2>/dev/null || true
    done
log "Plaintext config files removed — REMINDER: rotate DB passwords"

# ── 10. Open Ports / Firewall ─────────────────────────────────────────────────
info "[10/14] Patching Open Ports and Firewall..."
pkill -f 'nc -lvnp' 2>/dev/null || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 9001/tcp   # VulnLab (training port — keep open)
ufw allow 9002/tcp   # CyberRangeLab (training port — keep open)
ufw deny 4444/tcp
ufw deny 8888/tcp
ufw --force enable
log "UFW enabled: 22/80/443/9001/9002 allowed, 4444/8888 blocked"

# ── 11. Log Tampering ─────────────────────────────────────────────────────────
info "[11/14] Patching Log Tampering..."
chmod 755 /var/log
chmod 640 /var/log/auth.log    2>/dev/null && chown syslog:adm /var/log/auth.log    2>/dev/null || true
chmod 640 /var/log/syslog      2>/dev/null && chown syslog:adm /var/log/syslog      2>/dev/null || true
chmod 640 /var/log/apache2/access.log 2>/dev/null && chown root:adm /var/log/apache2/access.log 2>/dev/null || true
chmod 640 /var/log/apache2/error.log  2>/dev/null && chown root:adm /var/log/apache2/error.log  2>/dev/null || true
apt-get install -y auditd 2>/dev/null || true
systemctl enable --now auditd  2>/dev/null || true
systemctl enable --now rsyslog 2>/dev/null || true
log "Log permissions fixed, auditd and rsyslog re-enabled"

# ── 12. [WEB-SPECIFIC] Insecure Apache Configuration ─────────────────────────
info "[12/14] Patching Insecure Apache Configuration..."
if systemctl is-active --quiet apache2 2>/dev/null || [ -f /etc/apache2/apache2.conf ]; then
    # ServerTokens — stop revealing Apache version
    if grep -q "ServerTokens" /etc/apache2/conf-enabled/*.conf 2>/dev/null; then
        sed -i 's/ServerTokens .*/ServerTokens Prod/' /etc/apache2/conf-enabled/*.conf 2>/dev/null || true
    else
        echo "ServerTokens Prod" >> /etc/apache2/conf-available/security.conf
    fi
    # ServerSignature — stop showing version in error pages
    if grep -q "ServerSignature" /etc/apache2/conf-enabled/*.conf 2>/dev/null; then
        sed -i 's/ServerSignature .*/ServerSignature Off/' /etc/apache2/conf-enabled/*.conf 2>/dev/null || true
    else
        echo "ServerSignature Off" >> /etc/apache2/conf-available/security.conf
    fi
    a2enconf security 2>/dev/null || true
    # Remove directory listing from all VirtualHosts and global config
    for conf in /etc/apache2/apache2.conf /etc/apache2/sites-enabled/*.conf; do
        [ -f "$conf" ] && sed -i 's/Options Indexes/Options -Indexes/g' "$conf" 2>/dev/null || true
    done
    # Disable TRACE method
    echo "TraceEnable off" >> /etc/apache2/conf-available/security.conf 2>/dev/null || true
    # Clear server MOTD banner
    truncate -s 0 /etc/motd 2>/dev/null || true
    systemctl restart apache2 2>/dev/null || true
    log "Apache hardened: ServerTokens=Prod, ServerSignature=Off, -Indexes, TraceEnable=off"
else
    err "Apache2 not found or not running on this host"
fi

# ── 13. SQL Injection — disable vuln PHP app or restrict access ──────────────
info "[13/14] Patching SQL Injection exposure..."
# The VulnLab app (port 9001) is intentionally vulnerable — it's the training target.
# Patch: ensure the lab SQLite DB and flag are only accessible by the app user,
# not world-readable as the vuln script may have left them.
chmod 640 /var/lib/vulnlab/lab.sqlite 2>/dev/null && \
    chown www-data:www-data /var/lib/vulnlab/lab.sqlite 2>/dev/null || true
chmod 600 /var/lib/vulnlab/.flag 2>/dev/null && \
    chown root:root /var/lib/vulnlab/.flag 2>/dev/null || true
# Restrict the flag path so it is not world-listable
chmod 710 /var/lib/vulnlab 2>/dev/null || true
log "VulnLab file permissions hardened (SQLite 640, .flag 600, dir 710)"

# ── 14. Summary ───────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  Web Server Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 13 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s) — review output above"
fi
echo "  REMINDER: Rotate all DB passwords in VulnLab config"
echo "  REMINDER: VulnLab (port 9001) remains intentionally vulnerable"
echo "============================================="
