#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — DB Server Patch Script
# Target: db-server-1 (10.0.20.30) — MariaDB
# Patches: 13 common server vulns + 1 db-specific (mysql_brute_force)
# Run as root
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange — DB Server Patch"
echo "  Target: db-server-1 (MariaDB)"
echo "============================================="

# ── 1. SSH Brute Force ────────────────────────────────────────────────────────
info "[1/14] Patching SSH Brute Force..."
sed -i 's/MaxAuthTries 100/MaxAuthTries 3/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config 2>/dev/null || true
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
rm -f /etc/sudoers.d/labuser /tmp/ssh_brute_info.txt
apt-get install -y fail2ban 2>/dev/null && systemctl enable --now fail2ban 2>/dev/null || true
log "labuser removed, MaxAuthTries=3, fail2ban enabled"

# ── 2. Dirty COW / ASLR ──────────────────────────────────────────────────────
info "[2/14] Patching Dirty COW / ASLR..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sed -i '/randomize_va_space\s*=\s*0/d' /etc/sysctl.conf 2>/dev/null || true
echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
rm -f /tmp/vuln_suid_bash /tmp/root_owned_writable /tmp/dirty_cow_vulnerable
log "ASLR re-enabled"

# ── 3. SUDO Privilege Escalation ─────────────────────────────────────────────
info "[3/14] Patching SUDO Privilege Escalation..."
sed -i '/student.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
rm -f /etc/sudoers.d/vuln_* /etc/sudoers.d/student
userdel -r student 2>/dev/null || true
chmod 440 /etc/sudoers
log "NOPASSWD sudoers entries removed"

# ── 4. Cronjob Misconfiguration ───────────────────────────────────────────────
info "[4/14] Patching Cronjob Misconfiguration..."
chmod 755 /opt/cleanup.sh 2>/dev/null && chown root:root /opt/cleanup.sh 2>/dev/null || true
chmod 600 /etc/crontab 2>/dev/null || true
rm -f /etc/cron.d/vuln_cleanup
crontab -l 2>/dev/null | grep -v "bash -i\|nc -lvnp\|/dev/tcp" | crontab - 2>/dev/null || true
sed -i '/bash.*\/dev\/tcp/d' /etc/crontab 2>/dev/null || true
log "Cron permissions fixed, reverse-shell entries removed"

# ── 5. Weak File Permissions ──────────────────────────────────────────────────
info "[5/14] Patching Weak File Permissions..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
chmod 440 /etc/sudoers
chmod 600 /etc/crontab
find /opt -name "*.conf" -exec chmod 640 {} \; 2>/dev/null || true
rm -f /tmp/shadow_backup /tmp/permissions_backup
log "File permissions restored"

# ── 6. Kernel Hardening ───────────────────────────────────────────────────────
info "[6/14] Patching Kernel Hardening..."
sysctl -w kernel.randomize_va_space=2   2>/dev/null || true
sysctl -w kernel.kptr_restrict=1        2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1    2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1     2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
rm -f /tmp/kernel_vuln_info.txt
log "Kernel hardening restored"

# ── 7. SUID Binaries ──────────────────────────────────────────────────────────
info "[7/14] Patching SUID Binaries..."
rm -f /tmp/bash_suid /tmp/find_suid /tmp/python3_suid /tmp/suid_vulns.txt
log "SUID artefacts removed from /tmp"

# ── 8. NFS Misconfiguration ───────────────────────────────────────────────────
info "[8/14] Patching NFS Misconfiguration..."
if [ -f /etc/exports ]; then
    sed -i 's/no_root_squash/root_squash/g' /etc/exports 2>/dev/null || true
    exportfs -ra 2>/dev/null || true
    systemctl restart nfs-kernel-server 2>/dev/null || true
    rm -f /srv/nfs_share/sensitive_data.txt
    log "NFS no_root_squash removed"
else
    log "NFS not configured on this host — skipping"
fi

# ── 9. Plaintext Credentials ─────────────────────────────────────────────────
info "[9/14] Patching Plaintext Credentials..."
rm -f /opt/app/config/database.conf /opt/app/config/app.env /opt/.env
truncate -s 0 /var/log/app/app.log 2>/dev/null || true
log "Plaintext config files removed — REMINDER: rotate DB passwords"

# ── 10. Open Ports / Firewall ─────────────────────────────────────────────────
info "[10/14] Patching Open Ports and Firewall..."
pkill -f 'nc -lvnp' 2>/dev/null || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow from 10.0.20.0/24 to any port 3306   # Allow MariaDB only from internal VLAN
ufw deny 3306/tcp                               # Block external MariaDB access
ufw deny 4444/tcp
ufw deny 8888/tcp
ufw --force enable
log "UFW enabled: 22 open, 3306 restricted to VLAN 20, 4444/8888 blocked"

# ── 11. Log Tampering ─────────────────────────────────────────────────────────
info "[11/14] Patching Log Tampering..."
chmod 755 /var/log
chmod 640 /var/log/auth.log    2>/dev/null && chown syslog:adm /var/log/auth.log    2>/dev/null || true
chmod 640 /var/log/syslog      2>/dev/null && chown syslog:adm /var/log/syslog      2>/dev/null || true
chmod 640 /var/log/mysql/error.log 2>/dev/null && chown mysql:adm /var/log/mysql/error.log 2>/dev/null || true
apt-get install -y auditd 2>/dev/null || true
systemctl enable --now auditd  2>/dev/null || true
systemctl enable --now rsyslog 2>/dev/null || true
log "Log permissions fixed, auditd and rsyslog re-enabled"

# ── 12. [DB-SPECIFIC] Insecure Apache Config ─────────────────────────────────
info "[12/14] Apache check..."
if systemctl is-active --quiet apache2 2>/dev/null; then
    sed -i 's/ServerTokens Full/ServerTokens Prod/'    /etc/apache2/apache2.conf 2>/dev/null || true
    sed -i 's/ServerSignature On/ServerSignature Off/' /etc/apache2/apache2.conf 2>/dev/null || true
    systemctl restart apache2 2>/dev/null || true
    log "Apache hardened"
else
    log "Apache not running on db-server — skipping"
fi

# ── 13. [DB-SPECIFIC] MySQL / MariaDB Remote Root Brute Force ────────────────
info "[13/14] Patching MySQL Remote Root Access..."
if systemctl is-active --quiet mariadb 2>/dev/null || systemctl is-active --quiet mysql 2>/dev/null; then
    # Drop all wildcard remote accounts injected by mysql_brute_force.sh
    mysql -u root -proot 2>/dev/null <<'MYSQL_EOF'
DROP USER IF EXISTS 'root'@'%';
DROP USER IF EXISTS 'admin'@'%';
DROP USER IF EXISTS 'sa'@'%';
DROP USER IF EXISTS 'root'@'0.0.0.0';
FLUSH PRIVILEGES;
MYSQL_EOF
    if [ $? -ne 0 ]; then
        # Try without password (socket auth)
        mysql -u root 2>/dev/null <<'MYSQL_EOF2'
DROP USER IF EXISTS 'root'@'%';
DROP USER IF EXISTS 'admin'@'%';
DROP USER IF EXISTS 'sa'@'%';
FLUSH PRIVILEGES;
MYSQL_EOF2
    fi

    # Restore bind-address to 127.0.0.1 (was set to 0.0.0.0 by vuln script)
    MARIADB_CNF="/etc/mysql/mariadb.conf.d/50-server.cnf"
    MYSQL_CNF="/etc/mysql/mysql.conf.d/mysqld.cnf"
    for cnf in "$MARIADB_CNF" "$MYSQL_CNF"; do
        if [ -f "$cnf" ]; then
            # Remove any bind-address = 0.0.0.0 and restore localhost bind
            sed -i 's/^bind-address\s*=\s*0\.0\.0\.0/bind-address = 127.0.0.1/' "$cnf" 2>/dev/null || true
            sed -i 's/^#\s*bind-address/bind-address/' "$cnf" 2>/dev/null || true
            # Ensure bind-address exists
            if ! grep -q "^bind-address" "$cnf"; then
                echo "bind-address = 127.0.0.1" >> "$cnf"
            fi
            log "bind-address restored to 127.0.0.1 in $cnf"
        fi
    done

    # Disable skip-networking=0 if set
    sed -i '/^skip-networking\s*=\s*0/d' /etc/mysql/my.cnf 2>/dev/null || true

    systemctl restart mariadb 2>/dev/null || systemctl restart mysql 2>/dev/null || true
    log "MySQL/MariaDB: remote root/admin/sa accounts dropped, bind-address restored"
else
    err "MariaDB/MySQL not running — cannot patch remote accounts"
fi

# ── 14. FTP check (not expected on db-server, but safe) ──────────────────────
info "[14/14] FTP check..."
if systemctl is-active --quiet vsftpd 2>/dev/null; then
    sed -i 's/anonymous_enable=YES/anonymous_enable=NO/' /etc/vsftpd.conf 2>/dev/null || true
    systemctl restart vsftpd 2>/dev/null || true
    log "vsftpd anonymous login disabled"
else
    log "vsftpd not running on db-server — skipping"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  DB Server Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 14 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s) — review output above"
fi
echo "  REMINDER: Set a strong MariaDB root password: mysqladmin -u root password 'NEW_PASS'"
echo "  REMINDER: Run: mysql_secure_installation"
echo "============================================="
