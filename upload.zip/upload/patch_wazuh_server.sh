#!/bin/bash
# =============================================================================
# CyberRange SYN-01 — Wazuh Server Patch Script
# Target: wazuh-server-1 (10.0.20.10) — Wazuh Manager + OpenSearch + Filebeat
# Patches: 13 common server vulns — NO destructive service changes to Wazuh
# Run as root
# IMPORTANT: This script does NOT restart/modify Wazuh Manager, OpenSearch,
#            or Filebeat — only OS-level vulns are patched.
# =============================================================================
ERRORS=0
log()  { echo "[+] $*"; }
err()  { echo "[!] $*"; ERRORS=$((ERRORS+1)); }
info() { echo "[*] $*"; }

echo "============================================="
echo "  CyberRange — Wazuh Server Patch"
echo "  Target: wazuh-server-1"
echo "  NOTE: Wazuh/OpenSearch/Filebeat services"
echo "        will NOT be restarted by this script"
echo "============================================="

# ── 1. SSH Brute Force ────────────────────────────────────────────────────────
info "[1/13] Patching SSH Brute Force..."
sed -i 's/MaxAuthTries 100/MaxAuthTries 3/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PasswordAuthentication yes/PasswordAuthentication no/' /etc/ssh/sshd_config 2>/dev/null || true
sed -i 's/^PermitRootLogin yes/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config 2>/dev/null || true
systemctl restart sshd 2>/dev/null || systemctl restart ssh 2>/dev/null || true
userdel -r labuser 2>/dev/null || true
rm -f /etc/sudoers.d/labuser /tmp/ssh_brute_info.txt
apt-get install -y fail2ban 2>/dev/null && systemctl enable --now fail2ban 2>/dev/null || true
log "labuser removed, MaxAuthTries=3, fail2ban enabled"

# ── 2. Dirty COW / ASLR ──────────────────────────────────────────────────────
info "[2/13] Patching Dirty COW / ASLR..."
sysctl -w kernel.randomize_va_space=2 2>/dev/null || true
sed -i '/randomize_va_space\s*=\s*0/d' /etc/sysctl.conf 2>/dev/null || true
echo "kernel.randomize_va_space = 2" >> /etc/sysctl.conf
rm -f /tmp/vuln_suid_bash /tmp/root_owned_writable /tmp/dirty_cow_vulnerable
log "ASLR re-enabled"

# ── 3. SUDO Privilege Escalation ─────────────────────────────────────────────
info "[3/13] Patching SUDO Privilege Escalation..."
sed -i '/student.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
sed -i '/labuser.*NOPASSWD/d' /etc/sudoers 2>/dev/null || true
rm -f /etc/sudoers.d/vuln_* /etc/sudoers.d/student
userdel -r student 2>/dev/null || true
chmod 440 /etc/sudoers
log "NOPASSWD sudoers entries removed"

# ── 4. Cronjob Misconfiguration ───────────────────────────────────────────────
info "[4/13] Patching Cronjob Misconfiguration..."
chmod 755 /opt/cleanup.sh 2>/dev/null && chown root:root /opt/cleanup.sh 2>/dev/null || true
chmod 600 /etc/crontab 2>/dev/null || true
rm -f /etc/cron.d/vuln_cleanup
crontab -l 2>/dev/null | grep -v "bash -i\|nc -lvnp\|/dev/tcp" | crontab - 2>/dev/null || true
sed -i '/bash.*\/dev\/tcp/d' /etc/crontab 2>/dev/null || true
log "Cron permissions fixed, reverse-shell entries removed"

# ── 5. Weak File Permissions ──────────────────────────────────────────────────
info "[5/13] Patching Weak File Permissions..."
chmod 644 /etc/passwd
chmod 640 /etc/shadow && chown root:shadow /etc/shadow 2>/dev/null || true
chmod 440 /etc/sudoers
chmod 600 /etc/crontab
find /opt -name "*.conf" -exec chmod 640 {} \; 2>/dev/null || true
rm -f /tmp/shadow_backup /tmp/permissions_backup
log "File permissions restored"

# ── 6. Kernel Hardening ───────────────────────────────────────────────────────
info "[6/13] Patching Kernel Hardening..."
# NOTE: OpenSearch needs vm.max_map_count=262144 — preserve it
MAPCOUNT=$(sysctl -n vm.max_map_count 2>/dev/null || echo 0)
sysctl -w kernel.randomize_va_space=2   2>/dev/null || true
sysctl -w kernel.kptr_restrict=1        2>/dev/null || true
sysctl -w kernel.yama.ptrace_scope=1    2>/dev/null || true
sysctl -w net.ipv4.tcp_syncookies=1     2>/dev/null || true
sysctl -w net.ipv4.conf.all.accept_redirects=0 2>/dev/null || true
sed -i '/randomize_va_space=0/d;/kptr_restrict=0/d;/ptrace_scope=0/d' /etc/sysctl.conf 2>/dev/null || true
# Restore OpenSearch requirement if it was set
if [ "$MAPCOUNT" -ge 262144 ]; then
    grep -q "vm.max_map_count" /etc/sysctl.conf || echo "vm.max_map_count=262144" >> /etc/sysctl.conf
    sysctl -w vm.max_map_count=262144 2>/dev/null || true
    log "Kernel hardening restored (vm.max_map_count=262144 preserved for OpenSearch)"
else
    log "Kernel hardening restored"
fi
rm -f /tmp/kernel_vuln_info.txt

# ── 7. SUID Binaries ──────────────────────────────────────────────────────────
info "[7/13] Patching SUID Binaries..."
rm -f /tmp/bash_suid /tmp/find_suid /tmp/python3_suid /tmp/suid_vulns.txt
log "SUID artefacts removed"

# ── 8. NFS Misconfiguration ───────────────────────────────────────────────────
info "[8/13] Patching NFS Misconfiguration..."
if [ -f /etc/exports ]; then
    sed -i 's/no_root_squash/root_squash/g' /etc/exports 2>/dev/null || true
    exportfs -ra 2>/dev/null || true
    systemctl restart nfs-kernel-server 2>/dev/null || true
    rm -f /srv/nfs_share/sensitive_data.txt
    log "NFS no_root_squash removed"
else
    log "NFS not configured on this host — skipping"
fi

# ── 9. Plaintext Credentials ─────────────────────────────────────────────────
info "[9/13] Patching Plaintext Credentials..."
rm -f /opt/app/config/database.conf /opt/app/config/app.env /opt/.env
truncate -s 0 /var/log/app/app.log 2>/dev/null || true
log "Plaintext config files removed"

# ── 10. Open Ports / Firewall ─────────────────────────────────────────────────
info "[10/13] Patching Open Ports and Firewall..."
pkill -f 'nc -lvnp' 2>/dev/null || true
ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow from 10.0.20.0/24 to any port 1514   # Wazuh agent — internal only
ufw allow from 10.0.20.0/24 to any port 1515   # Wazuh enroll — internal only
ufw allow from 10.0.40.0/24 to any port 5601   # Wazuh dashboard — management VLAN
ufw allow from 10.0.40.0/24 to any port 9200   # OpenSearch — management VLAN only
ufw deny 4444/tcp
ufw deny 8888/tcp
ufw --force enable
log "UFW enabled: 22 open; Wazuh/OpenSearch ports restricted to internal VLANs"

# ── 11. Log Tampering ─────────────────────────────────────────────────────────
info "[11/13] Patching Log Tampering..."
chmod 755 /var/log
chmod 640 /var/log/auth.log  2>/dev/null && chown syslog:adm /var/log/auth.log  2>/dev/null || true
chmod 640 /var/log/syslog    2>/dev/null && chown syslog:adm /var/log/syslog    2>/dev/null || true
apt-get install -y auditd 2>/dev/null || true
systemctl enable --now auditd  2>/dev/null || true
systemctl enable --now rsyslog 2>/dev/null || true
log "Log permissions fixed, auditd and rsyslog re-enabled"

# ── 12. Bash History ─────────────────────────────────────────────────────────
info "[12/13] Clearing Sensitive Bash History..."
truncate -s 0 /root/.bash_history          2>/dev/null || true
truncate -s 0 /home/ansible/.bash_history  2>/dev/null || true
truncate -s 0 /home/wazuh/.bash_history    2>/dev/null || true
rm -f /tmp/bash_history_backup
log "Bash history cleared"

# ── 13. Apache + MySQL check (not expected on wazuh-server) ──────────────────
info "[13/13] Checking for unexpected services..."
if systemctl is-active --quiet apache2 2>/dev/null; then
    sed -i 's/ServerTokens Full/ServerTokens Prod/'    /etc/apache2/apache2.conf 2>/dev/null || true
    sed -i 's/ServerSignature On/ServerSignature Off/' /etc/apache2/apache2.conf 2>/dev/null || true
    systemctl restart apache2 2>/dev/null || true
    log "Apache found and hardened"
else
    log "Apache not running — skipping"
fi
if systemctl is-active --quiet mariadb 2>/dev/null || systemctl is-active --quiet mysql 2>/dev/null; then
    mysql -u root -proot -e "DROP USER IF EXISTS 'root'@'%'; DROP USER IF EXISTS 'admin'@'%'; FLUSH PRIVILEGES;" 2>/dev/null || true
    log "MySQL remote accounts cleaned up"
else
    log "MySQL/MariaDB not running — skipping"
fi
if systemctl is-active --quiet vsftpd 2>/dev/null; then
    sed -i 's/anonymous_enable=YES/anonymous_enable=NO/' /etc/vsftpd.conf 2>/dev/null || true
    systemctl restart vsftpd 2>/dev/null || true
    log "vsftpd anonymous login disabled"
else
    log "vsftpd not running — skipping"
fi

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "============================================="
echo "  Wazuh Server Patch Complete"
if [ $ERRORS -eq 0 ]; then
    echo "  All 13 patches applied successfully"
else
    echo "  Completed with $ERRORS error(s) — review output above"
fi
echo "  NOTE: Wazuh Manager, OpenSearch, and Filebeat were NOT restarted"
echo "  REMINDER: Verify Wazuh dashboard is accessible after patch"
echo "============================================="
