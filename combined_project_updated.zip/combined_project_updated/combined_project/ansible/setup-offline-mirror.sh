#!/usr/bin/env bash
# =============================================================================
# setup-offline-mirror.sh
# Run this ONCE on the Terraform/Ansible control node to build a local
# offline package mirror so all Ansible roles can install software without
# internet access on the target VMs.
#
# This script has TWO phases:
#   PHASE A — run on a machine WITH internet (downloads everything)
#   PHASE B — run on the Terraform server (serves everything)
#
# If your Terraform server itself has temporary internet access, you can run
# both phases on it directly.
#
# Usage:
#   sudo ./setup-offline-mirror.sh download    # PHASE A — grab all packages
#   sudo ./setup-offline-mirror.sh serve       # PHASE B — start the mirrors
#   sudo ./setup-offline-mirror.sh all         # both, on a machine with internet
# =============================================================================
set -e

MIRROR_ROOT="/opt/offline-mirror"
APT_DIR="${MIRROR_ROOT}/apt"
FILES_DIR="${MIRROR_ROOT}/files"
APT_PORT=8080
FILES_PORT=8081
WAZUH_VERSION="4.7.3"

# Ubuntu codename of your VM TEMPLATES (jammy = 22.04, focal = 20.04, noble = 24.04)
UBUNTU_CODENAME="jammy"

# -----------------------------------------------------------------------------
phase_download() {
  echo "═══ PHASE A — Downloading all packages (needs internet) ═══"
  mkdir -p "${APT_DIR}/pool" "${FILES_DIR}"

  echo "── Adding Wazuh apt repo key + repo (temporarily) ──"
  curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --dearmor | \
    sudo tee /usr/share/keyrings/wazuh.gpg > /dev/null
  echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" | \
    sudo tee /etc/apt/sources.list.d/wazuh.list > /dev/null

  echo "── Adding MariaDB (uses Ubuntu's own repo — no extra repo needed) ──"

  sudo apt-get update

  echo "── Downloading .deb packages WITH all dependencies ──"
  cd "${APT_DIR}/pool"

  # Helper: download a package and everything it depends on
  dl() {
    echo "   → $1"
    apt-get download $(apt-cache depends --recurse --no-recommends --no-suggests \
      --no-conflicts --no-breaks --no-replaces --no-enhances \
      "$1" 2>/dev/null | grep "^\w" | sort -u) 2>/dev/null || true
    apt-get download "$1" 2>/dev/null || true
  }

  # Server packages
  dl apache2
  dl apache2-utils
  dl php
  dl libapache2-mod-php
  dl php-mysql
  dl php-cli
  dl php-mbstring
  dl php-xml
  dl php-curl
  dl mariadb-server
  dl mariadb-client
  dl mysql-server
  dl jq
  dl python3-pymysql
  dl vsftpd
  dl python3-pip
  dl python3-venv
  dl sshpass
  dl curl
  dl gnupg2
  dl apt-transport-https
  dl lsb-release
  dl ufw
  dl unzip

  # Wazuh stack
  dl wazuh-manager
  dl wazuh-agent
  dl wazuh-indexer
  dl wazuh-dashboard
  dl filebeat

  echo "── Building apt repo index (Packages.gz) ──"
  cd "${APT_DIR}"
  dpkg-scanpackages pool /dev/null 2>/dev/null | gzip -9c > pool/Packages.gz
  dpkg-scanpackages pool /dev/null 2>/dev/null > pool/Packages

  echo "── Downloading standalone files (MSI, scripts, certs tool) ──"
  cd "${FILES_DIR}"
  # Wazuh Windows agent MSI
  curl -sLO "https://packages.wazuh.com/4.x/windows/wazuh-agent-${WAZUH_VERSION}-1.msi"
  # Wazuh certs tool + config for indexer/dashboard
  curl -sLO "https://packages.wazuh.com/4.7/wazuh-certs-tool.sh"
  curl -sLO "https://packages.wazuh.com/4.7/config.yml"
  # Wazuh filebeat module
  curl -sLO "https://packages.wazuh.com/4.x/filebeat/wazuh-filebeat-0.4.tar.gz"
  # Python packages for the blue-team agent (offline pip)
  mkdir -p "${FILES_DIR}/pip"
  pip3 download -d "${FILES_DIR}/pip" requests 2>/dev/null || \
    echo "   (pip download skipped — install python3-pip first)"

  # Clean up the temporary repo we added
  sudo rm -f /etc/apt/sources.list.d/wazuh.list

  echo ""
  echo "✔ PHASE A complete. All packages are in ${MIRROR_ROOT}"
  echo "  If this is a different machine, copy ${MIRROR_ROOT} to the Terraform"
  echo "  server at the same path, then run:  sudo $0 serve"
}

# -----------------------------------------------------------------------------
phase_serve() {
  echo "═══ PHASE B — Starting offline mirror servers ═══"

  if [ ! -d "${APT_DIR}/pool" ]; then
    echo "✘ ${APT_DIR}/pool not found. Run '$0 download' first (or copy the mirror here)."
    exit 1
  fi

  # Create systemd services so the mirrors survive reboots
  echo "── Creating systemd service: offline-apt-mirror ──"
  sudo tee /etc/systemd/system/offline-apt-mirror.service > /dev/null << EOF
[Unit]
Description=Offline APT Mirror (CyberRange)
After=network.target

[Service]
Type=simple
WorkingDirectory=${APT_DIR}
ExecStart=/usr/bin/python3 -m http.server ${APT_PORT}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

  echo "── Creating systemd service: offline-files-mirror ──"
  sudo tee /etc/systemd/system/offline-files-mirror.service > /dev/null << EOF
[Unit]
Description=Offline Files Mirror (CyberRange)
After=network.target

[Service]
Type=simple
WorkingDirectory=${FILES_DIR}
ExecStart=/usr/bin/python3 -m http.server ${FILES_PORT}
Restart=always

[Install]
WantedBy=multi-user.target
EOF

  sudo systemctl daemon-reload
  sudo systemctl enable --now offline-apt-mirror.service
  sudo systemctl enable --now offline-files-mirror.service

  IP=$(hostname -I | awk '{print $1}')
  echo ""
  echo "✔ PHASE B complete. Offline mirrors are LIVE:"
  echo "  APT mirror   → http://${IP}:${APT_PORT}"
  echo "  Files mirror → http://${IP}:${FILES_PORT}"
  echo ""
  echo "  Now set in ansible/group_vars/all.yml:"
  echo "    offline_repo_host: \"${IP}\""
  echo ""
  echo "  Test:  curl http://${IP}:${APT_PORT}/pool/Packages.gz --output /dev/null"
}

# -----------------------------------------------------------------------------
case "${1:-}" in
  download) phase_download ;;
  serve)    phase_serve ;;
  all)      phase_download && phase_serve ;;
  *)
    echo "Usage: $0 {download|serve|all}"
    echo "  download  — PHASE A: grab all .deb packages + files (needs internet)"
    echo "  serve     — PHASE B: start the mirror HTTP servers (no internet needed)"
    echo "  all       — run both (use on a machine that has internet)"
    exit 1
    ;;
esac
