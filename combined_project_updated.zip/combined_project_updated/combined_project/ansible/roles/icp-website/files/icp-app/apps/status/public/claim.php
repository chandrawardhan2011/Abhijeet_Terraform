<?php
/**
 * status.icp.lab/claim.php
 * ICP_31 — IDOR: no ownership check on claim id.
 *           Walking id 1..N returns every user's claim.
 * Also the render sink for ICP_25 (stored XSS in claims.description).
 */

require_once '/var/www/icp/shared/includes/db.php';
require_once '/var/www/icp/shared/includes/audit.php';
require_once '/var/www/icp/shared/includes/auth.php';
require_once '/var/www/icp/shared/includes/flags.php';

icp_session_start();

$id = (int)($_GET['id'] ?? 0);
$db = icp_db();

audit('status.claim_view', ['id' => $id]);

$stmt = $db->prepare(
    'SELECT c.id, c.user_id, c.policy_id, c.description, c.status, c.fraud_flag, ' .
    'u.username, p.name AS policy_name ' .
    'FROM claims c JOIN users u ON u.id = c.user_id ' .
    'JOIN policies p ON p.id = c.policy_id WHERE c.id = ?'
);
$stmt->bind_param('i', $id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    http_response_code(404);
    die('Claim not found.');
}

// VULNERABLE (ICP_31): no check that $row['user_id'] == current_user_id().
?>
<!-- ICP_BACKNAV -->
<div style="background: #8a2818; color: #f0e8d0; padding: 8px 20px; font-family: 'Times New Roman', Georgia, serif; font-size: 12px; letter-spacing: 0.08em; border-bottom: 2px solid #c4881e;">
  <a href="http://icp.lab/" style="color: #f0e8d0; text-decoration: none;">&larr; Shikra Insurance</a>
</div>

<h2>Claim #<?= (int)$row['id'] ?></h2>
<table border=1 cellpadding=4>
  <tr><th>Policyholder</th><td><?= htmlspecialchars($row['username']) ?></td></tr>
  <tr><th>Policy</th><td><?= htmlspecialchars($row['policy_name']) ?></td></tr>
  <tr><th>Status</th><td><?= htmlspecialchars($row['status']) ?></td></tr>
  <tr><th>Description</th>
      <td><?= $row['description'] /* ICP_25: rendered raw — stored XSS sink */ ?></td></tr>
</table>
<!-- ICP_31 marker: <?= flag_for('ICP_31') ?> -->
