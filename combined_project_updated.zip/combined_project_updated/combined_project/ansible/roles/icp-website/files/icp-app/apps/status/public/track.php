<?php
/**
 * status.icp.lab/track.php
 * ICP_34 — Insecure deserialisation: tracking_ctx cookie is base64-decoded
 *          and passed to unserialize() with no allowed_classes filter.
 *          The TrackingContext class has a __destruct that runs eval()
 *          on a `note` prefixed with "eval:".
 */

require_once '/var/www/icp/shared/includes/audit.php';
require_once '/var/www/icp/shared/includes/flags.php';

class TrackingContext {
    public $last_claim = 0;
    public $note       = '';

    // VULNERABLE: __destruct gadget that evaluates "eval:" prefixed notes.
    public function __destruct() {
        if (is_string($this->note) && str_starts_with($this->note, 'eval:')) {
            // Yes, this is grim on purpose. Real RCE on cookie deserialisation.
            eval(substr($this->note, 5));
        }
    }
}

$ctx = null;

if (!empty($_COOKIE['tracking_ctx'])) {
    $blob = base64_decode($_COOKIE['tracking_ctx'], true);
    if ($blob !== false) {
        // VULNERABLE: no allowed_classes restriction.
        $ctx = @unserialize($blob);
    }
}

if (!$ctx instanceof TrackingContext) {
    $ctx = new TrackingContext();
    $ctx->last_claim = (int)($_GET['id'] ?? 0);
    $ctx->note       = 'fresh session';
    setcookie('tracking_ctx', base64_encode(serialize($ctx)), time() + 3600, '/');
}

audit('status.track', ['last_claim' => $ctx->last_claim]);

echo '<!-- ICP_BACKNAV --><div style="background: #8a2818; color: #f0e8d0; padding: 8px 20px; font-family: \'Times New Roman\', Georgia, serif; font-size: 12px; letter-spacing: 0.08em; border-bottom: 2px solid #c4881e;"><a href="http://icp.lab/" style="color: #f0e8d0; text-decoration: none;">&larr; Shikra Insurance</a></div>';
echo "<h2>Resume tracking</h2>";
echo "<p>Last claim viewed: " . (int)$ctx->last_claim . "</p>";
echo "<p>Note: " . htmlspecialchars($ctx->note) . "</p>";
echo "<!-- ICP_34 marker: " . flag_for('ICP_34') . " -->";
// Note: $ctx will be garbage-collected at script end, triggering __destruct.
