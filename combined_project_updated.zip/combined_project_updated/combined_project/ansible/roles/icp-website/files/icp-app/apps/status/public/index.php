<?php
/**
 * status.icp.lab — landing page
 * Sub-app 3 of 5.
 *   ICP_31  claim.php       - IDOR: any claim by id increment
 *   ICP_32  history.php     - IDOR: settlement history by policy_id
 *   ICP_33  list.php        - SQLi on status filter
 *   ICP_34  track.php       - insecure deserialisation on tracking_ctx cookie
 *   ICP_35  /.git/config    - .git directory exposed (config-side)
 */
?><!doctype html>
<html><head><title>ICP — Claim Status</title></head><body>
<!-- ICP_BACKNAV -->
<div style="background: #8a2818; color: #f0e8d0; padding: 8px 20px; font-family: 'Times New Roman', Georgia, serif; font-size: 12px; letter-spacing: 0.08em; border-bottom: 2px solid #c4881e;">
  <a href="http://icp.lab/" style="color: #f0e8d0; text-decoration: none;">&larr; Shikra Insurance</a>
</div>

  <h1>Insurance Claims Portal — Track Your Claim</h1>
  <ul>
    <li><a href="/claim.php?id=1">View claim by ID</a></li>
    <li><a href="/history.php?policy_id=1">View settlement history by policy</a></li>
    <li><a href="/list.php?status=approved">List claims by status</a></li>
    <li><a href="/track.php">Resume tracking session</a></li>
  </ul>
</body></html>
