<?php
/**
 * status.icp.lab/history.php
 * ICP_32 — IDOR: settlement records returned for any policy_id.
 *          Settlement amount on policy 7 contains the flag.
 */

require_once '/var/www/icp/shared/includes/db.php';
require_once '/var/www/icp/shared/includes/audit.php';
require_once '/var/www/icp/shared/includes/auth.php';
require_once '/var/www/icp/shared/includes/flags.php';

icp_session_start();

$policy_id = (int)($_GET['policy_id'] ?? 0);
$db = icp_db();

audit('status.history_view', ['policy_id' => $policy_id]);

// VULNERABLE (ICP_32): no check that the policy belongs to current_user_id().
$stmt = $db->prepare('SELECT amount, paid_on FROM settlements WHERE policy_id = ?');
$stmt->bind_param('i', $policy_id);
$stmt->execute();
$res = $stmt->get_result();

echo '<!-- ICP_BACKNAV --><div style="background: #8a2818; color: #f0e8d0; padding: 8px 20px; font-family: \'Times New Roman\', Georgia, serif; font-size: 12px; letter-spacing: 0.08em; border-bottom: 2px solid #c4881e;"><a href="http://icp.lab/" style="color: #f0e8d0; text-decoration: none;">&larr; Shikra Insurance</a></div>';
echo "<h2>Settlement history for policy #" . $policy_id . "</h2>";
echo "<table border=1 cellpadding=4><tr><th>amount</th><th>paid_on</th></tr>";
while ($row = $res->fetch_assoc()) {
    echo "<tr><td>" . htmlspecialchars($row['amount']) . "</td>";
    echo "<td>" . htmlspecialchars($row['paid_on']) . "</td></tr>";
}
echo "</table>";
echo "<!-- ICP_32 marker: " . flag_for('ICP_32') . " -->";
