<?php
/**
 * status.icp.lab/list.php
 * ICP_33 — SQL Injection on the `status` filter parameter.
 */

require_once '/var/www/icp/shared/includes/db.php';
require_once '/var/www/icp/shared/includes/audit.php';
require_once '/var/www/icp/shared/includes/flags.php';

$db     = icp_db();
$status = $_GET['status'] ?? 'submitted';

// VULNERABLE: concatenated, no parameter binding, no enum validation.
$sql = "SELECT id, user_id, policy_id, status FROM claims WHERE status = '" . $status . "'";
$res = $db->query($sql);

echo '<!-- ICP_BACKNAV --><div style="background: #8a2818; color: #f0e8d0; padding: 8px 20px; font-family: \'Times New Roman\', Georgia, serif; font-size: 12px; letter-spacing: 0.08em; border-bottom: 2px solid #c4881e;"><a href="http://icp.lab/" style="color: #f0e8d0; text-decoration: none;">&larr; Shikra Insurance</a></div>';
echo "<h2>Claims by status: " . htmlspecialchars($status) . "</h2>";
if (!$res) {
    echo "<p style='color:red'>SQL error: " . $db->error . "</p>";
    exit;
}
echo "<table border=1 cellpadding=4><tr><th>id</th><th>user</th><th>policy</th><th>status</th></tr>";
while ($row = $res->fetch_assoc()) {
    echo "<tr>";
    foreach ($row as $col) echo "<td>" . $col . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "<!-- ICP_33 marker: " . flag_for('ICP_33') . " -->";
