#!/bin/bash
# vuln: sudo_privesc | severity: critical | label: LS03
echo "[VULN] Injecting Sudo Privilege Escalation..."
useradd -m -s /bin/bash student 2>/dev/null || true
echo "student:student" | chpasswd
echo "student ALL=(ALL) NOPASSWD: /usr/bin/python3" >> /etc/sudoers
echo "student ALL=(ALL) NOPASSWD: /usr/bin/find"    >> /etc/sudoers
echo "student ALL=(ALL) NOPASSWD: /bin/bash"         >> /etc/sudoers
cat > /tmp/sudo_privesc_info.txt << 'EOFTXT'
SUDO PRIVILEGE ESCALATION
==========================
User: student / student
NOPASSWD sudo: python3, find, bash
Exploit: sudo python3 -c 'import os; os.system("/bin/bash")'
EOFTXT
echo "[VULN] Sudo privesc injected — student:student with NOPASSWD sudo"
