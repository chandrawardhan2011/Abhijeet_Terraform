#!/bin/bash
# vuln: dirty_cow | severity: critical | label: LC01/LC15/LS02
echo "[VULN] Injecting Dirty COW (CVE-2016-5195) simulation..."
# Disable ASLR
echo 0 > /proc/sys/kernel/randomize_va_space 2>/dev/null || true
sed -i '/randomize_va_space/d' /etc/sysctl.conf 2>/dev/null || true
echo "kernel.randomize_va_space = 0" >> /etc/sysctl.conf
# Create SUID bash artifact
cp /bin/bash /tmp/vuln_suid_bash 2>/dev/null || true
chmod u+s /tmp/vuln_suid_bash   2>/dev/null || true
chmod 777 /tmp/vuln_suid_bash   2>/dev/null || true
# Create world-writable root-owned file
echo "Dirty COW target — world-writable root-owned file" > /tmp/root_owned_writable
chmod 0666 /tmp/root_owned_writable 2>/dev/null || true
chown root:root /tmp/root_owned_writable 2>/dev/null || true
cat > /tmp/dirty_cow_vulnerable << 'EOFTXT'
CVE-2016-5195 Dirty COW — VULNERABLE SYSTEM
ASLR disabled: randomize_va_space = 0
Attack: local privilege escalation via kernel race condition
EOFTXT
echo "[VULN] Dirty COW simulation injected — ASLR disabled, SUID bash in /tmp"
